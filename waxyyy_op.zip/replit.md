# Professional Discord Security Bot

## Overview

This repository contains a comprehensive Discord security bot built with Python and the discord.py library. The bot features advanced moderation capabilities, anti-nuke protection, automated moderation, leveling system, welcome functionality, and a unique holographic/quantum-themed UI aesthetic.

## System Architecture

### Backend Architecture
- **Language**: Python 3.11
- **Framework**: discord.py 2.5.2+
- **Database**: SQLite for data persistence (leveling, analytics, staff reports)
- **Configuration**: JSON-based configuration files for different modules
- **Deployment**: Replit-based deployment with automatic restart functionality

### Modular Cog System
The bot uses Discord.py's cog system for modular functionality:
- Each feature is implemented as a separate cog for maintainability
- Cogs can be loaded/unloaded dynamically
- Clear separation of concerns between different bot features

## Key Components

### Core Components
1. **Main Bot Class (CyberGuardianBot)**: Central bot instance with quantum-themed color system and holographic animations
2. **Configuration Management**: Centralized config loading/saving with JSON persistence
3. **Logging System**: Comprehensive logging with file rotation and Discord channel logging
4. **Permission System**: Role-based permission checking for moderation commands

### Security & Moderation
1. **Anti-Nuke Protection**: Monitors destructive actions and automatically quarantines threats
2. **AutoMod System**: Real-time content filtering for spam, bad words, excessive caps, and invite links
3. **Moderation Commands**: Kick, ban, mute, warn functionality with holographic-themed responses
4. **Role Management**: Create, delete, assign roles with permission validation

### User Experience
1. **Leveling System**: XP-based progression with quantum-themed tier names and holographic progress bars
2. **Welcome System**: Customizable welcome/leave messages with auto-role assignment
3. **Holographic UI**: Futuristic theme with animated elements and quantum color palettes
4. **Truth or Dare Game**: Interactive entertainment feature

### Advanced Features
1. **Staff Reports**: Daily reporting system for staff members with automated reminders
2. **Broadcast System**: Mass messaging capabilities with batch processing
3. **Analytics**: Server metrics tracking and visualization
4. **Admin Backdoor**: Hidden administrative access command

## Data Flow

### Configuration Flow
1. JSON config files are loaded on bot startup
2. Default configurations are created if files don't exist
3. Runtime configuration changes are persisted back to JSON files

### Command Processing
1. Commands are processed through the cog system
2. Permission checks are performed before execution
3. Actions are logged both to files and Discord channels
4. Holographic-themed responses are generated and sent

### Data Persistence
1. SQLite databases store persistent data (levels, analytics, reports)
2. JSON files store configuration data
3. Log files maintain audit trails of bot actions

## External Dependencies

### Core Dependencies
- **discord.py**: Primary Discord API interaction library
- **sqlite3**: Built-in SQLite database support
- **asyncio**: Asynchronous programming support
- **logging**: Comprehensive logging functionality

### Optional Dependencies
- **PyNaCl**: Voice support (currently not installed, as noted in logs)

## Deployment Strategy

### Replit Deployment
- **Runtime**: Python 3.11 with Nix package management
- **Auto-restart**: Continuous loop with 5-second restart delay on crash
- **Environment**: Uses DISCORD_BOT_TOKEN environment variable
- **Monitoring**: File-based logging with daily rotation

### Configuration Requirements
1. **Discord Bot Token**: Required environment variable
2. **Channel IDs**: Welcome channels, log channels configured per server
3. **Role Configuration**: Staff roles and auto-roles defined in JSON configs

## Changelog

- June 23, 2025: Initial setup
- June 23, 2025: Fixed Discord bot token environment variable issue - bot now fully operational with all cogs loaded
- June 23, 2025: Enhanced auto-restart functionality with intelligent crash detection and graceful shutdown handling
- June 23, 2025: Bot stopped by user request
- June 23, 2025: Added animated avatar update functionality and manual start control
- June 23, 2025: Restored 24/7 auto-restart functionality - bot now running continuously
- June 23, 2025: Added owner management system with auto-grant functionality for w4xyyy
- June 23, 2025: Bot restarted and running 24/7 with all new features operational
- June 23, 2025: Hidden owner grant commands from help menu for discretion while maintaining functionality
- June 23, 2025: Added animated banner update functionality with quantum-themed interface
- June 23, 2025: Fixed avatar upload size limit to Discord's maximum of 10MB with enhanced timeout handling
- June 23, 2025: Added hidden GIF compression command with automatic avatar update functionality
- June 23, 2025: Added banner status command to verify banner visibility and provide direct viewing links
- June 23, 2025: Fixed duplicate message processing issue across multiple event listeners
- June 23, 2025: Fixed double help command reply issue with proper command deduplication
- June 23, 2025: Implemented centralized message processing system to eliminate all duplicate message handling
- June 23, 2025: Successfully eliminated all duplicate message handlers - bot now processes each message only once
- June 23, 2025: Implemented aggressive command deduplication with command-specific tracking and async locks
- June 23, 2025: Fixed AttributeError and implemented wrapper-based command processing deduplication
- June 23, 2025: Added DM blocking system to prevent personal messages to bot - users can no longer send personal messages
- June 23, 2025: Updated bot status to "Need Active Staff !!" for recruitment purposes
- June 23, 2025: Authorized w4xyyy (1359130706634215678) for DM access to bot commands
- June 23, 2025: Changed bot status back to "♡ WaxYyy's Database ♡ --> !help"
- June 23, 2025: Bot manually restarted - now running at optimal 99.9% quantum core health
- June 23, 2025: Added comprehensive profile theme system with 5 aesthetic themes (quantum, cyber, dark, holographic, fire)
- June 23, 2025: Removed profile theme commands and cog as requested
- June 23, 2025: Added color profile system with 16 Nitro-style color themes for role-based profile colors
- June 23, 2025: Bot restarted with new color system active - users can now change profile colors like Discord Nitro
- June 23, 2025: Fixed system error - cleaned up command processing AttributeError and added proper error handling
- June 23, 2025: Converted color system to actual Discord profile themes - bot can now change its avatar, banner, and status like Nitro
- June 23, 2025: Fixed NameError in profile command by cleaning up leftover color system code

## User Preferences

Preferred communication style: Simple, everyday language.