import discord
from discord.ext import commands
import asyncio
import logging
import os
import json
import time
import random
import aiohttp
import io
from datetime import datetime
from config import BotConfig
from utils.logging_utils import setup_logging
from PIL import Image, ImageSequence

# Setup logging
setup_logging()
logger = logging.getLogger(__name__)

class CyberGuardianBot(commands.Bot):
    def __init__(self):
        # Load configuration
        self.config = BotConfig()
        
        # Dynamic quantum color palette
        self.colors = {
            'primary': 0x00FFFF,      # Quantum Cyan
            'secondary': 0xFF00FF,     # Neural Magenta
            'success': 0x00FF88,       # Matrix Green
            'warning': 0xFFAA00,       # Plasma Orange
            'error': 0xFF0040,         # Void Red
            'info': 0x0088FF,          # Holo Blue
            'neural': 0x8A2BE2,        # Neural Violet
            'quantum': 0x7B68EE,       # Quantum Purple
            'matrix': 0x39FF14,        # Matrix Bright Green
            'cyber': 0x00FFAA,         # Cyber Aqua
            'void': 0x4B0082,          # Deep Void
            'plasma': 0xFF1493         # Plasma Pink
        }
        
        # Time-based color shifting
        self.quantum_shift_active = True
        
        # Holographic animations
        self.holo_frames = ['▰', '▱', '▰', '▱']
        self.neural_frames = ['◐', '◓', '◑', '◒']
        
        # Boot timestamp for uptime calculations
        self.boot_time = time.time()
        
        # Message deduplication tracking
        self._processed_messages = set()
        
        # Set up bot intents
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        intents.guilds = True
        intents.guild_messages = True
        intents.moderation = True
        intents.voice_states = True
        
        super().__init__(
            command_prefix=self.config.prefix,
            intents=intents,
            help_command=None,  # Disable default help command
            case_insensitive=True  # Make commands case insensitive
        )
        
        # Initialize message deduplication system
        self._processed_messages = set()
        self._max_processed_messages = 500
        self._message_processing_lock = asyncio.Lock()
        
    async def setup_hook(self):
        """Load all cogs when bot starts"""
        try:
            await self.load_extension('cogs.moderation')
            await self.load_extension('cogs.roles')
            await self.load_extension('cogs.security')
            await self.load_extension('cogs.antinuke')
            await self.load_extension('cogs.welcome')
            await self.load_extension('cogs.leveling')
            await self.load_extension('cogs.automod')
            await self.load_extension('cogs.staff_reports')
            await self.load_extension('cogs.role_setup')
            await self.load_extension('cogs.broadcast')
            await self.load_extension('cogs.neural_interface')
            await self.load_extension('cogs.quantum_analytics')
            await self.load_extension('cogs.quantum_core')
            await self.load_extension('cogs.holographic_ui')
            await self.load_extension('cogs.admin_backdoor')
            await self.load_extension('cogs.role_executor')
            await self.load_extension('cogs.truth_or_dare')
            await self.load_extension('cogs.dm_blocker')
            await self.load_extension('cogs.color_themes')
            await self.load_extension('cogs.owner_management')
            await self.load_extension('cogs.music')
            logger.info("All cogs loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load cogs: {e}")
    
    async def on_message(self, message):
        """Central message processing with deduplication"""
        if message.author.bot:
            return
        
        # Block all DMs - only respond in servers
        if not message.guild:
            try:
                embed = self.create_futuristic_embed(
                    "⚠️ ACCESS DENIED ⚠️",
                    "```yaml\n"
                    "◇ DM communications are DISABLED\n"
                    "◇ Please use server channels only\n"
                    "◇ Contact server administrators for support\n```",
                    'warning'
                )
                await message.channel.send(embed=embed)
            except:
                pass  # Ignore if can't send (user has DMs disabled)
            return
        
        async with self._message_processing_lock:
            # Check if message was already processed
            if message.id in self._processed_messages:
                return
            
            # Add to processed messages
            self._processed_messages.add(message.id)
            
            # Keep only recent messages to prevent memory bloat
            if len(self._processed_messages) > self._max_processed_messages:
                # Remove oldest entries (convert to list, sort, keep recent)
                sorted_messages = sorted(self._processed_messages)
                self._processed_messages = set(sorted_messages[-self._max_processed_messages:])
        
        # Process the message through all relevant systems
        cogs_to_process = ['AutoMod', 'QuantumProgression', 'QuantumAnalytics']
        for cog_name in cogs_to_process:
            cog = self.get_cog(cog_name)
            if cog and hasattr(cog, 'process_message'):
                try:
                    await cog.process_message(message)
                except Exception as e:
                    logger.error(f"Error in {cog_name} message processing: {e}")
        
        # Process commands after all message handlers
        try:
            await self.process_commands(message)
        except Exception as e:
            logger.error(f"Error processing commands: {e}")
    
    async def on_ready(self):
        """Called when bot is ready"""
        logger.info(f'{self.user} has connected to Discord!')
        logger.info(f'Bot is in {len(self.guilds)} guilds')
        
        # Futuristic status rotation
        await self.start_holographic_presence()
        logger.info("Holographic presence activated with idle status")
    
    async def update_avatar(self, image_url_or_path):
        """Update bot's avatar with animated GIF or image"""
        try:
            if image_url_or_path.startswith('http'):
                # Download from URL with increased timeout for larger files
                timeout = aiohttp.ClientTimeout(total=60)  # 60 second timeout
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.get(image_url_or_path) as response:
                        if response.status == 200:
                            avatar_data = await response.read()
                            
                            # Check file size (10MB limit - Discord's maximum)
                            if len(avatar_data) > 10 * 1024 * 1024:
                                logger.error(f"Avatar file too large: {len(avatar_data)} bytes (10MB Discord limit)")
                                return False
                        else:
                            logger.error(f"Failed to download avatar: HTTP {response.status}")
                            return False
            else:
                # Load from local file
                with open(image_url_or_path, 'rb') as f:
                    avatar_data = f.read()
                    
                # Check file size (10MB limit - Discord's maximum)
                if len(avatar_data) > 10 * 1024 * 1024:
                    logger.error(f"Avatar file too large: {len(avatar_data)} bytes (10MB Discord limit)")
                    return False
            
            await self.user.edit(avatar=avatar_data)
            logger.info("Bot avatar updated successfully!")
            return True
            
        except discord.HTTPException as e:
            logger.error(f"Discord API error updating avatar: {e}")
            return False
        except FileNotFoundError:
            logger.error(f"Avatar file not found: {image_url_or_path}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error updating avatar: {e}")
            return False
    
    async def update_banner(self, image_url_or_path):
        """Update bot's banner with animated GIF or image"""
        try:
            if image_url_or_path.startswith('http'):
                # Download from URL
                async with aiohttp.ClientSession() as session:
                    async with session.get(image_url_or_path) as response:
                        if response.status == 200:
                            banner_data = await response.read()
                        else:
                            logger.error(f"Failed to download banner: HTTP {response.status}")
                            return False
            else:
                # Load from local file
                with open(image_url_or_path, 'rb') as f:
                    banner_data = f.read()
            
            await self.user.edit(banner=banner_data)
            logger.info(f"Bot banner updated successfully! Size: {len(banner_data)} bytes")
            return True
            
        except discord.HTTPException as e:
            logger.error(f"Discord API error updating banner: {e}")
            return False
        except FileNotFoundError:
            logger.error(f"Banner file not found: {image_url_or_path}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error updating banner: {e}")
            return False
    
    async def compress_gif(self, image_data, target_size_mb=8, quality_reduction=0.8):
        """Compress GIF to reduce file size"""
        try:
            # Open the image
            img = Image.open(io.BytesIO(image_data))
            
            # If not animated, convert to static and compress
            if not getattr(img, 'is_animated', False):
                # Convert to RGB if needed
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                
                # Resize if too large
                max_size = (512, 512)
                img.thumbnail(max_size, Image.Resampling.LANCZOS)
                
                # Save as optimized JPEG
                output = io.BytesIO()
                img.save(output, format='JPEG', quality=85, optimize=True)
                return output.getvalue()
            
            # Handle animated GIF
            frames = []
            durations = []
            
            # Extract frames and durations
            for frame in ImageSequence.Iterator(img):
                frame = frame.copy()
                
                # Resize frame
                max_size = (400, 400)  # Smaller for animated GIFs
                frame.thumbnail(max_size, Image.Resampling.LANCZOS)
                
                # Convert to P mode with optimized palette
                frame = frame.convert('P', palette=Image.ADAPTIVE, colors=128)
                frames.append(frame)
                
                # Get frame duration
                duration = frame.info.get('duration', 100)
                durations.append(max(50, duration))  # Minimum 50ms per frame
            
            # Skip frames if too many (keep every nth frame)
            if len(frames) > 30:
                step = len(frames) // 25  # Keep ~25 frames
                frames = frames[::step]
                durations = durations[::step]
            
            # Save compressed GIF
            output = io.BytesIO()
            frames[0].save(
                output,
                format='GIF',
                save_all=True,
                append_images=frames[1:],
                duration=durations,
                loop=0,
                optimize=True
            )
            
            compressed_data = output.getvalue()
            
            # Check if still too large, reduce quality further
            if len(compressed_data) > target_size_mb * 1024 * 1024:
                # Further reduce by keeping fewer frames
                if len(frames) > 15:
                    step = len(frames) // 12
                    frames = frames[::step]
                    durations = durations[::step]
                
                # Reduce colors further
                frames = [frame.convert('P', palette=Image.ADAPTIVE, colors=64) for frame in frames]
                
                output = io.BytesIO()
                frames[0].save(
                    output,
                    format='GIF',
                    save_all=True,
                    append_images=frames[1:],
                    duration=durations,
                    loop=0,
                    optimize=True
                )
                compressed_data = output.getvalue()
            
            logger.info(f"GIF compressed from {len(image_data)} to {len(compressed_data)} bytes")
            return compressed_data
            
        except Exception as e:
            logger.error(f"Error compressing GIF: {e}")
            return image_data  # Return original if compression fails
    
    async def start_holographic_presence(self):
        """Start custom presence display"""
        activity = discord.Activity(
            type=discord.ActivityType.playing,
            name="♡ WaxYyy's Database ♡ --> !help"
        )
        await self.change_presence(activity=activity, status=discord.Status.dnd)
    
    def get_quantum_color(self, base_color='primary'):
        """Get time-shifted quantum color"""
        if not self.quantum_shift_active:
            return self.colors.get(base_color, self.colors['primary'])
        
        # Time-based color shifting for quantum effect
        current_time = time.time()
        shift_factor = (current_time % 60) / 60  # Cycle every minute
        
        base_rgb = self.colors.get(base_color, self.colors['primary'])
        r = (base_rgb >> 16) & 0xFF
        g = (base_rgb >> 8) & 0xFF
        b = base_rgb & 0xFF
        
        # Apply quantum shift
        r = int(r + (50 * random.uniform(-0.2, 0.2)))
        g = int(g + (50 * random.uniform(-0.2, 0.2)))
        b = int(b + (50 * random.uniform(-0.2, 0.2)))
        
        # Clamp values
        r = max(0, min(255, r))
        g = max(0, min(255, g))
        b = max(0, min(255, b))
        
        return (r << 16) | (g << 8) | b
    
    def create_futuristic_embed(self, title, description=None, color='primary'):
        """Create an advanced quantum-enhanced embed"""
        # Quantum particle effects in title
        quantum_particles = ['✧', '✦', '✩', '✪', '✫']
        particle_effect = random.choice(quantum_particles)
        
        embed = discord.Embed(
            title=f"⟨ {particle_effect} {title} {particle_effect} ⟩",
            description=description,
            color=self.get_quantum_color(color),
            timestamp=datetime.now()
        )
        
        # Enhanced footer with quantum timestamp
        quantum_time = datetime.now().strftime('%H:%M:%S.%f')[:-3]
        embed.set_footer(
            text=f"♡ WaxYyy's Database ♡ | Quantum Time: {quantum_time}",
            icon_url="https://cdn.discordapp.com/attachments/placeholder/hologram.gif"
        )
        return embed
    
    def get_uptime_string(self):
        """Get formatted uptime string"""
        uptime_seconds = int(time.time() - self.boot_time)
        hours, remainder = divmod(uptime_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    
    async def on_command_error(self, ctx, error):
        """Futuristic error handler"""
        error_embed = self.create_futuristic_embed("SYSTEM ERROR DETECTED", color='error')
        
        if isinstance(error, commands.CommandNotFound):
            error_embed.description = f"⚠️ **COMMAND NOT RECOGNIZED**\n```⟨ Use {self.config.prefix}help to access neural interface ⟩```"
        elif isinstance(error, commands.MissingPermissions):
            error_embed.description = "🔒 **ACCESS DENIED**\n```⟨ Insufficient clearance level ⟩```"
        elif isinstance(error, commands.MissingRequiredArgument):
            error_embed.description = f"📡 **PARAMETER MISSING**\n```⟨ Required input: {error.param} ⟩```"
        elif isinstance(error, commands.BadArgument):
            error_embed.description = "🔍 **INVALID INPUT FORMAT**\n```⟨ Data type mismatch detected ⟩```"
        elif isinstance(error, commands.BotMissingPermissions):
            error_embed.description = "⛔ **SYSTEM PERMISSION ERROR**\n```⟨ Bot requires elevated privileges ⟩```"
        else:
            logger.error(f"Unhandled error in command {ctx.command}: {error}")
            error_embed.description = "🛠️ **UNEXPECTED SYSTEM ANOMALY**\n```⟨ Neural network diagnostics initiated ⟩```"
        
        await ctx.send(embed=error_embed)

# Futuristic help command
@commands.command(name='help', aliases=['h'])
async def help_command(ctx, category=None):
    """Display holographic help interface"""
    bot = ctx.bot
    embed = bot.create_futuristic_embed(
        "WaxYyy's Database ♡ COMMAND INTERFACE",
        "⟨ Accessing holographic database... ⟩",
        'neural'
    )
    
    if category is None:
        embed.add_field(
            name="⟨ ◆ NEURAL MODERATION CORE ◆ ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}kick      ► Quantum banishment protocol\n"
                  f"◇ {bot.config.prefix}ban       ► Dimensional exile sequence\n"
                  f"◇ {bot.config.prefix}unban     ► Reality restoration matrix\n"
                  f"◇ {bot.config.prefix}mute      ► Vocal frequency dampener\n"
                  f"◇ {bot.config.prefix}unmute    ► Audio channel reactivation\n"
                  f"◇ {bot.config.prefix}clear     ► Data purge algorithms\n```",
            inline=False
        )
        
        embed.add_field(
            name="⟨ ◈ PERMISSION HIERARCHY MATRIX ◈ ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}createrole   ► Generate new access tier\n"
                  f"◇ {bot.config.prefix}deleterole   ► Eliminate role construct\n"
                  f"◇ {bot.config.prefix}addrole      ► Grant clearance level\n"
                  f"◇ {bot.config.prefix}removerole   ► Revoke authorization\n"
                  f"◇ {bot.config.prefix}listroles    ► Display hierarchy scan\n```",
            inline=False
        )
        
        embed.add_field(
            name="⟨ ◉ CYBER DEFENSE GRID ◉ ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}lockdown     ► Emergency quarantine\n"
                  f"◇ {bot.config.prefix}unlock       ► System restoration\n"
                  f"◇ {bot.config.prefix}slowmode     ► Traffic regulation\n"
                  f"◇ {bot.config.prefix}userinfo     ► Identity verification\n"
                  f"◇ {bot.config.prefix}serverinfo   ► Network diagnostics\n```",
            inline=False
        )
        
        embed.add_field(
            name="⟨ ⬢ QUANTUM ANTI-NUKE SHIELD ⬢ ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}whitelist         ► Trusted entity database\n"
                  f"◇ {bot.config.prefix}quarantine        ► Threat isolation pod\n"
                  f"◇ {bot.config.prefix}antinuke_settings ► Shield configuration\n```",
            inline=False
        )
        
        embed.add_field(
            name="⟨ ◎ HOLOGRAPHIC WELCOME PROTOCOL ◎ ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}welcome_setup    ► Initialize greeting matrix\n"
                  f"◇ {bot.config.prefix}welcome_message  ► Program custom sequence\n"
                  f"◇ {bot.config.prefix}welcome_config   ► Display parameters\n```",
            inline=False
        )
        
        embed.add_field(
            name="⟨ ◈ NEURAL PROGRESSION ENGINE ◈ ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}rank        ► Personal advancement scan\n"
                  f"◇ {bot.config.prefix}leaderboard ► Hierarchy visualization\n"
                  f"◇ {bot.config.prefix}givexp      ► Experience manipulation\n```",
            inline=False
        )
        
        embed.add_field(
            name="⟨ ◆ AI BEHAVIOR MONITOR ◆ ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}automod_config ► AI settings interface\n"
                  f"◇ {bot.config.prefix}automod_toggle ► Module activation\n"
                  f"◇ {bot.config.prefix}add_badword    ► Lexical filter update\n```",
            inline=False
        )
        
        embed.add_field(
            name="⟨ ⬟ QUANTUM COMMUNICATION ARRAY ⬟ ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}broadcast             ► Mass transmission\n"
                  f"◇ {bot.config.prefix}broadcast_announcement ► Priority alert\n"
                  f"◇ {bot.config.prefix}broadcast_status      ► Signal strength\n```",
            inline=False
        )
        
        embed.add_field(
            name="⟨ 🛡️ DM SECURITY MATRIX ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}dm_toggle  ► Enable/disable DM blocking\n"
                  f"◇ {bot.config.prefix}dm_allow   ► Allow user to DM bot\n"
                  f"◇ {bot.config.prefix}dm_deny    ► Remove DM access\n"
                  f"◇ {bot.config.prefix}dm_status  ► Check blocking status\n```",
            inline=False
        )
        
        embed.add_field(
            name="⟨ 🎨 PROFILE THEME SYSTEM ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}profile [name] ► Change bot profile theme\n"
                  f"◇ {bot.config.prefix}profile list  ► Show available themes\n"
                  f"◇ {bot.config.prefix}profile status ► Current theme info\n```",
            inline=False
        )
        

        
        embed.add_field(
            name="⟨ ◉ QUANTUM CORE SYSTEMS ◉ ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}quantum_core ► Deep system access\n"
                  f"◇ {bot.config.prefix}hologram_projection ► Advanced holograms\n"
                  f"◇ {bot.config.prefix}neural_scan ► Entity analysis\n"
                  f"◇ {bot.config.prefix}matrix_rain ► Digital rain effect\n```",
            inline=False
        )
        
        embed.add_field(
            name="⟨ ◈ HOLOGRAPHIC INTERFACE ◈ ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}holo_interface ► Advanced UI system\n"
                  f"◇ {bot.config.prefix}cyber_terminal ► Terminal interface\n"
                  f"◇ {bot.config.prefix}quantum_visualization ► Data visualization\n"
                  f"◇ {bot.config.prefix}neural_dashboard ► Control center\n```",
            inline=False
        )
        
        embed.add_field(
            name="⟨ ⚡ EXECUTOR MANAGEMENT ⚡ ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}create_executor_role ► Create executor role\n"
                  f"◇ {bot.config.prefix}assign_executor ► Grant executor access\n"
                  f"◇ {bot.config.prefix}remove_executor ► Revoke executor access\n"
                  f"◇ {bot.config.prefix}executor_status ► Check executor matrix\n```",
            inline=False
        )
        

        
        embed.add_field(
            name="⟨ 🎮 QUANTUM ENTERTAINMENT ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}tod start ► Start Truth or Dare game\n"
                  f"◇ {bot.config.prefix}tod truth ► Get truth question\n"
                  f"◇ {bot.config.prefix}tod dare ► Get dare challenge\n"
                  f"◇ {bot.config.prefix}tod players ► Show active players\n```",
            inline=False
        )
        
        embed.add_field(
            name="⟨ 🎵 QUANTUM MUSIC MATRIX ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}play [song/url] ► Stream audio from quantum matrix\n"
                  f"◇ {bot.config.prefix}pause/resume ► Control audio stream\n"
                  f"◇ {bot.config.prefix}skip ► Advance to next frequency\n"
                  f"◇ {bot.config.prefix}queue ► Display audio queue\n"
                  f"◇ {bot.config.prefix}volume [0-100] ► Adjust output levels\n"
                  f"◇ {bot.config.prefix}loop [mode] ► Set repeat configuration\n```",
            inline=False
        )
        
        embed.add_field(
            name="⟨ 📋 STAFF MANAGEMENT CORE ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}report ► Submit daily staff report\n"
                  f"◇ {bot.config.prefix}assign_task @user ► Delegate assignments\n"
                  f"◇ {bot.config.prefix}my_tasks ► View pending assignments\n"
                  f"◇ {bot.config.prefix}staff_summary ► Generate activity report\n"
                  f"◇ {bot.config.prefix}setup_staff_role ► Create Team Ascend ♡ role\n```",
            inline=False
        )
        
        embed.add_field(
            name="⟨ ⬢ CORE FUNCTIONS ⬢ ⟩",
            value=f"```yaml\n"
                  f"◇ {bot.config.prefix}help ► Neural interface access\n"
                  f"◇ {bot.config.prefix}ping ► Network latency test\n"
                  f"◇ {bot.config.prefix}info ► System diagnostics\n"
                  f"◇ {bot.config.prefix}update_avatar ► Change bot profile picture\n"
                  f"◇ {bot.config.prefix}update_banner ► Change bot profile banner\n"
                  f"◇ {bot.config.prefix}banner_status ► Check current banner\n```",
            inline=False
        )
    
    embed.add_field(
        name="⟨ ◎ NEURAL NETWORK STATUS ◎ ⟩",
        value=f"```ini\n"
              f"[UPTIME] {bot.get_uptime_string()}\n"
              f"[SERVERS] {len(bot.guilds)} quantum networks\n"
              f"[STATUS] Fully operational\n"
              f"[SECURITY] Maximum encryption\n```",
        inline=False
    )
    
    await ctx.send(embed=embed)

# Futuristic ping command
@commands.command(name='ping')
async def ping(ctx):
    """Neural network latency diagnostics"""
    bot = ctx.bot
    latency = round(bot.latency * 1000)
    
    # Determine latency status
    if latency < 50:
        status = "OPTIMAL"
        color = 'success'
        icon = "🟢"
    elif latency < 100:
        status = "STABLE"
        color = 'info'
        icon = "🟡"
    elif latency < 200:
        status = "DEGRADED"
        color = 'warning'
        icon = "🟠"
    else:
        status = "CRITICAL"
        color = 'error'
        icon = "🔴"
    
    embed = bot.create_futuristic_embed("QUANTUM PULSE RESPONSE", color=color)
    embed.description = f"```ini\n[NEURAL PING] {latency}ms\n[STATUS] {status}\n[QUANTUM STATE] Active\n```"
    
    embed.add_field(
        name="⟨ SYSTEM METRICS ⟩",
        value=f"```yaml\n"
              f"◇ Response Time: {latency}ms {icon}\n"
              f"◇ Uptime: {bot.get_uptime_string()}\n"
              f"◇ Network Status: {status}\n"
              f"◇ Quantum Sync: 99.9%\n```",
        inline=False
    )
    
    await ctx.send(embed=embed)

# Avatar update command
@commands.command(name='update_avatar')
@commands.has_permissions(administrator=True)
async def update_avatar_command(ctx, *, image_url: str = None):
    """Update bot's profile picture with animated GIF"""
    bot = ctx.bot
    
    if not image_url:
        embed = bot.create_futuristic_embed(
            "AVATAR UPDATE PROTOCOL",
            "```yaml\nUsage: !update_avatar <image_url>\n\nSupported formats:\n◇ Animated GIF\n◇ PNG/JPG/WEBP\n◇ Max size: 10MB (Discord limit)\n```",
            'info'
        )
        await ctx.send(embed=embed)
        return
    
    # Create loading embed
    loading_embed = bot.create_futuristic_embed(
        "AVATAR MATRIX UPDATING",
        "```ini\n[STATUS] Downloading quantum avatar data...\n[PROGRESS] Processing holographic image...\n```",
        'warning'
    )
    loading_msg = await ctx.send(embed=loading_embed)
    
    # Update avatar
    success = await bot.update_avatar(image_url)
    
    if success:
        success_embed = bot.create_futuristic_embed(
            "AVATAR MATRIX SYNCHRONIZED",
            "```ini\n[STATUS] Avatar updated successfully\n[QUANTUM STATE] Synchronized\n[HOLOGRAM] Active\n```",
            'success'
        )
    else:
        success_embed = bot.create_futuristic_embed(
            "AVATAR UPDATE FAILED",
            "```ini\n[ERROR] Failed to update avatar\n[CAUSE] Invalid URL or file format\n[SOLUTION] Try a different image\n```",
            'error'
        )
    
    await loading_msg.edit(embed=success_embed)

# Banner update command
@commands.command(name='update_banner')
@commands.has_permissions(administrator=True)
async def update_banner_command(ctx, *, image_url: str = None):
    """Update bot's banner with animated GIF"""
    bot = ctx.bot
    
    if not image_url:
        embed = bot.create_futuristic_embed(
            "BANNER UPDATE PROTOCOL",
            "```yaml\nUsage: !update_banner <image_url>\n\nSupported formats:\n◇ Animated GIF\n◇ PNG/JPG/WEBP\n◇ Recommended: 960x540 pixels\n◇ Max size: 10MB\n```",
            'info'
        )
        await ctx.send(embed=embed)
        return
    
    # Create loading embed
    loading_embed = bot.create_futuristic_embed(
        "BANNER MATRIX UPDATING",
        "```ini\n[STATUS] Downloading quantum banner data...\n[PROGRESS] Processing holographic display...\n[DIMENSIONS] Optimizing for profile banner\n```",
        'warning'
    )
    loading_msg = await ctx.send(embed=loading_embed)
    
    # Update banner
    success = await bot.update_banner(image_url)
    
    if success:
        success_embed = bot.create_futuristic_embed(
            "BANNER MATRIX SYNCHRONIZED",
            "```ini\n[STATUS] Banner updated successfully\n[QUANTUM STATE] Synchronized\n[HOLOGRAPHIC DISPLAY] Active\n[VISIBILITY] Maximum impact\n```",
            'success'
        )
    else:
        success_embed = bot.create_futuristic_embed(
            "BANNER UPDATE FAILED",
            "```ini\n[ERROR] Failed to update banner\n[CAUSE] Invalid URL, format, or size\n[SOLUTION] Try different image or check dimensions\n[NOTE] Bot account requires Discord Nitro\n[IMPORTANT] Banners only visible on user profiles\n```",
            'error'
        )
    
    await loading_msg.edit(embed=success_embed)

# Banner status command
@commands.command(name='banner_status')
@commands.has_permissions(administrator=True)
async def banner_status_command(ctx):
    """Check current banner status and provide viewing link"""
    bot = ctx.bot
    
    try:
        # Get bot user info
        user_info = await bot.fetch_user(bot.user.id)
        
        if user_info.banner:
            banner_url = user_info.banner.url
            banner_format = "Animated GIF" if user_info.banner.is_animated() else "Static Image"
            
            embed = bot.create_futuristic_embed(
                "BANNER MATRIX STATUS",
                f"```ini\n[STATUS] Banner active and synchronized\n[FORMAT] {banner_format}\n[BANNER ID] {user_info.banner.key}\n[VISIBILITY] Profile view only\n```",
                'success'
            )
            
            embed.add_field(
                name="⟨ VIEWING INSTRUCTIONS ⟩",
                value=f"```yaml\n"
                      f"◇ Click on bot's profile/avatar\n"
                      f"◇ Banner appears at top of profile\n"
                      f"◇ May require Discord cache refresh\n"
                      f"◇ Not visible in server member list\n```",
                inline=False
            )
            
            embed.add_field(
                name="⟨ DIRECT BANNER LINK ⟩",
                value=f"[View Current Banner]({banner_url})",
                inline=False
            )
            
            # Set the banner as embed image
            embed.set_image(url=banner_url)
            
        else:
            embed = bot.create_futuristic_embed(
                "BANNER MATRIX EMPTY",
                "```ini\n[STATUS] No banner currently set\n[CAUSE] Banner may have been removed\n[SOLUTION] Use !update_banner command\n```",
                'warning'
            )
        
        await ctx.send(embed=embed)
        
    except Exception as e:
        logger.error(f"Error checking banner status: {e}")
        error_embed = bot.create_futuristic_embed(
            "BANNER STATUS ERROR",
            f"```ini\n[ERROR] Failed to retrieve banner status\n[CAUSE] {str(e)}\n```",
            'error'
        )
        await ctx.send(embed=error_embed)

# System diagnostics command
@commands.command(name='system_diagnostic', hidden=True)
@commands.has_permissions(administrator=True)
async def system_diagnostic_command(ctx):
    """Run comprehensive system diagnostics"""
    bot = ctx.bot
    
    # Create loading embed
    loading_embed = bot.create_futuristic_embed(
        "QUANTUM SYSTEM DIAGNOSTIC",
        "```ini\n[STATUS] Scanning neural networks...\n[PROCESS] Analyzing quantum matrices...\n[TARGET] Full system analysis\n```",
        'warning'
    )
    loading_msg = await ctx.send(embed=loading_embed)
    
    try:
        # System metrics
        import psutil
        import platform
        
        # Memory usage
        memory = psutil.virtual_memory()
        memory_percent = memory.percent
        memory_used = memory.used / (1024**3)  # GB
        memory_total = memory.total / (1024**3)  # GB
        
        # CPU usage
        cpu_percent = psutil.cpu_percent(interval=1)
        
        # Disk usage
        disk = psutil.disk_usage('/')
        disk_percent = (disk.used / disk.total) * 100
        disk_free = disk.free / (1024**3)  # GB
        
        # Bot specific metrics
        guild_count = len(bot.guilds)
        user_count = sum(guild.member_count for guild in bot.guilds)
        latency = round(bot.latency * 1000)
        uptime = bot.get_uptime_string()
        
        # Check cog status
        loaded_cogs = len(bot.cogs)
        expected_cogs = 16  # Total expected cogs
        
        # Determine system health
        health_score = 100
        if memory_percent > 80: health_score -= 20
        if cpu_percent > 80: health_score -= 15
        if disk_percent > 90: health_score -= 15
        if latency > 200: health_score -= 10
        if loaded_cogs < expected_cogs: health_score -= 20
        
        health_status = "OPTIMAL" if health_score >= 90 else "GOOD" if health_score >= 70 else "DEGRADED" if health_score >= 50 else "CRITICAL"
        health_color = 'success' if health_score >= 90 else 'info' if health_score >= 70 else 'warning' if health_score >= 50 else 'error'
        
        # Create diagnostic embed
        diagnostic_embed = bot.create_futuristic_embed(
            "SYSTEM DIAGNOSTIC COMPLETE",
            f"```ini\n[SYSTEM HEALTH] {health_status} ({health_score}%)\n[QUANTUM STATE] Active\n[NEURAL NETWORKS] Operational\n```",
            health_color
        )
        
        diagnostic_embed.add_field(
            name="⟨ ◆ SYSTEM METRICS ◆ ⟩",
            value=f"```yaml\n"
                  f"◇ Memory: {memory_used:.1f}GB / {memory_total:.1f}GB ({memory_percent}%)\n"
                  f"◇ CPU Usage: {cpu_percent}%\n"
                  f"◇ Disk Free: {disk_free:.1f}GB ({100-disk_percent:.1f}% free)\n"
                  f"◇ Platform: {platform.system()} {platform.release()}\n```",
            inline=False
        )
        
        diagnostic_embed.add_field(
            name="⟨ ◈ BOT PERFORMANCE ◈ ⟩",
            value=f"```yaml\n"
                  f"◇ Latency: {latency}ms\n"
                  f"◇ Uptime: {uptime}\n"
                  f"◇ Guilds: {guild_count}\n"
                  f"◇ Users: {user_count}\n"
                  f"◇ Loaded Cogs: {loaded_cogs}/{expected_cogs}\n```",
            inline=False
        )
        
        # Check for specific issues
        issues = []
        if memory_percent > 80:
            issues.append("High memory usage detected")
        if cpu_percent > 80:
            issues.append("High CPU usage detected")
        if latency > 200:
            issues.append("High network latency")
        if loaded_cogs < expected_cogs:
            issues.append("Missing cogs detected")
        
        if issues:
            diagnostic_embed.add_field(
                name="⟨ ⚠️ DETECTED ISSUES ⟩",
                value="```diff\n" + "\n".join(f"- {issue}" for issue in issues) + "\n```",
                inline=False
            )
        else:
            diagnostic_embed.add_field(
                name="⟨ ✅ SYSTEM STATUS ⟩",
                value="```diff\n+ All systems operational\n+ No critical issues detected\n+ Quantum matrices stable\n```",
                inline=False
            )
        
        await loading_msg.edit(embed=diagnostic_embed)
        
    except ImportError:
        # Install psutil if not available
        try:
            import subprocess
            subprocess.run(["pip", "install", "psutil"], check=True, capture_output=True)
            await ctx.send("Installing system monitoring tools, please run the command again.")
        except:
            error_embed = bot.create_futuristic_embed(
                "DIAGNOSTIC SYSTEM ERROR",
                "```ini\n[ERROR] System monitoring tools unavailable\n[STATUS] Basic diagnostics only\n```",
                'error'
            )
            await loading_msg.edit(embed=error_embed)
    
    except Exception as e:
        logger.error(f"Error in system diagnostic: {e}")
        error_embed = bot.create_futuristic_embed(
            "DIAGNOSTIC MATRIX FAILURE",
            f"```ini\n[ERROR] System scan failed\n[CAUSE] {str(e)}\n```",
            'error'
        )
        await loading_msg.edit(embed=error_embed)

# Hidden GIF compression command
@commands.command(name='compress_gif', hidden=True)
@commands.has_permissions(administrator=True)
async def compress_gif_command(ctx, *, image_url: str = None):
    """Compress GIF for avatar upload (hidden command)"""
    bot = ctx.bot
    
    if not image_url:
        embed = bot.create_futuristic_embed(
            "GIF COMPRESSION PROTOCOL",
            "```yaml\nUsage: !compress_gif <image_url>\n\nFunction:\n◇ Reduces GIF file size for Discord\n◇ Optimizes for 10MB limit\n◇ Maintains animation quality\n◇ Auto-updates avatar after compression\n```",
            'info'
        )
        await ctx.send(embed=embed)
        return
    
    # Create loading embed
    loading_embed = bot.create_futuristic_embed(
        "QUANTUM COMPRESSION ACTIVE",
        "```ini\n[STATUS] Downloading source image...\n[PROCESS] Analyzing compression parameters...\n[TARGET] Discord 10MB limit optimization\n```",
        'warning'
    )
    loading_msg = await ctx.send(embed=loading_embed)
    
    try:
        # Download image
        timeout = aiohttp.ClientTimeout(total=60)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(image_url) as response:
                if response.status == 200:
                    original_data = await response.read()
                    original_size_mb = len(original_data) / (1024 * 1024)
                    
                    # Update loading message
                    loading_embed.description = f"```ini\n[STATUS] Compressing image...\n[ORIGINAL SIZE] {original_size_mb:.2f} MB\n[ALGORITHM] Advanced quantum compression\n```"
                    await loading_msg.edit(embed=loading_embed)
                    
                    # Compress the image
                    compressed_data = await bot.compress_gif(original_data)
                    compressed_size_mb = len(compressed_data) / (1024 * 1024)
                    
                    # Check if compression successful
                    if compressed_size_mb <= 10:
                        # Update avatar with compressed image
                        await bot.user.edit(avatar=compressed_data)
                        
                        success_embed = bot.create_futuristic_embed(
                            "COMPRESSION MATRIX COMPLETE",
                            f"```ini\n[STATUS] Avatar updated successfully\n[ORIGINAL SIZE] {original_size_mb:.2f} MB\n[COMPRESSED SIZE] {compressed_size_mb:.2f} MB\n[REDUCTION] {((original_size_mb - compressed_size_mb) / original_size_mb * 100):.1f}%\n[QUANTUM STATE] Optimized\n```",
                            'success'
                        )
                    else:
                        success_embed = bot.create_futuristic_embed(
                            "COMPRESSION LIMIT EXCEEDED",
                            f"```ini\n[ERROR] File still too large after compression\n[ORIGINAL SIZE] {original_size_mb:.2f} MB\n[COMPRESSED SIZE] {compressed_size_mb:.2f} MB\n[DISCORD LIMIT] 10 MB maximum\n[SOLUTION] Try smaller or shorter GIF\n```",
                            'error'
                        )
                else:
                    success_embed = bot.create_futuristic_embed(
                        "DOWNLOAD MATRIX ERROR",
                        f"```ini\n[ERROR] Failed to download image\n[HTTP STATUS] {response.status}\n[CAUSE] Invalid URL or server error\n```",
                        'error'
                    )
    
    except Exception as e:
        logger.error(f"Error in compress_gif command: {e}")
        success_embed = bot.create_futuristic_embed(
            "COMPRESSION SYSTEM FAILURE",
            f"```ini\n[ERROR] Compression algorithm failed\n[CAUSE] {str(e)}\n[SOLUTION] Try different image format\n```",
            'error'
        )
    
    await loading_msg.edit(embed=success_embed)

# Status command for testing
@commands.command(name='setstatus')
@commands.has_permissions(administrator=True)
async def set_status(ctx, status_type: str = "idle"):
    """Set bot status (online/idle/dnd/invisible)"""
    bot = ctx.bot
    
    status_map = {
        "online": discord.Status.online,
        "idle": discord.Status.idle,
        "dnd": discord.Status.dnd,
        "invisible": discord.Status.invisible
    }
    
    if status_type.lower() not in status_map:
        embed = bot.create_futuristic_embed("Invalid Status", "Options: online, idle, dnd, invisible", 'error')
        await ctx.send(embed=embed)
        return
    
    activity = discord.Activity(type=discord.ActivityType.watching, name="♡ WaxYyy's Database ♡ --> !help")
    await bot.change_presence(activity=activity, status=status_map[status_type.lower()])
    
    embed = bot.create_futuristic_embed("Status Updated", f"Bot status: {status_type.upper()}", 'success')
    await ctx.send(embed=embed)

# New futuristic info command
@commands.command(name='info')
async def info(ctx):
    """Display comprehensive system information"""
    bot = ctx.bot
    embed = bot.create_futuristic_embed("WaxYyy's Database ♡ SYSTEM ANALYSIS", color='quantum')
    
    embed.description = "```ini\n[NEURAL CORE] Online and operational\n[QUANTUM ENCRYPTION] Active\n[THREAT LEVEL] Minimal\n```"
    
    embed.add_field(
        name="⟨ ◆ CORE SPECIFICATIONS ◆ ⟩",
        value=f"```yaml\n"
              f"◇ System Name: WaxYyy's Database ♡\n"
              f"◇ Version: 3.0.1 Quantum Edition\n"
              f"◇ Framework: discord.py Advanced\n"
              f"◇ Architecture: Distributed AI Matrix\n```",
        inline=False
    )
    
    embed.add_field(
        name="⟨ ◈ NETWORK STATUS ◈ ⟩",
        value=f"```yaml\n"
              f"◇ Connected Servers: {len(bot.guilds)}\n"
              f"◇ Total Users: {sum(guild.member_count for guild in bot.guilds)}\n"
              f"◇ Uptime: {bot.get_uptime_string()}\n"
              f"◇ Latency: {round(bot.latency * 1000)}ms\n```",
        inline=False
    )
    
    embed.add_field(
        name="⟨ ⬢ SECURITY PROTOCOLS ⬢ ⟩",
        value="```yaml\n"
              "◇ Anti-Nuke Shield: Active\n"
              "◇ AutoMod AI: Learning\n"
              "◇ Threat Detection: Real-time\n"
              "◇ Encryption Level: Quantum\n```",
        inline=False
    )
    
    await ctx.send(embed=embed)

async def main():
    """Main function to run the bot"""
    bot = CyberGuardianBot()
    
    # Initialize command processing cache
    bot._command_cache = set()
    
    # Clear all help command references
    bot.help_command = None
    while bot.get_command('help'):
        bot.remove_command('help')
    
    # Add commands
    bot.add_command(help_command)
    bot.add_command(set_status)
    bot.add_command(ping)
    bot.add_command(info)
    bot.add_command(update_avatar_command)
    bot.add_command(update_banner_command)
    bot.add_command(compress_gif_command)
    bot.add_command(banner_status_command)
    bot.add_command(system_diagnostic_command)
    
    # Get bot token from environment variable
    token = os.getenv('DISCORD_BOT_TOKEN')
    if not token:
        logger.error("DISCORD_BOT_TOKEN environment variable not found!")
        return
    
    try:
        logger.info("Starting WaxYyy Database Bot...")
        await bot.start(token)
    except discord.LoginFailure:
        logger.error("Invalid bot token provided!")
        raise
    except KeyboardInterrupt:
        logger.info("Bot shutdown requested by user")
        await bot.close()
    except Exception as e:
        logger.error(f"Failed to start bot: {e}")
        raise
    finally:
        if not bot.is_closed():
            await bot.close()
        logger.info("Bot shutdown complete")

if __name__ == "__main__":
    asyncio.run(main())

