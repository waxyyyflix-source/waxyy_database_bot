import discord
from discord.ext import commands
import sqlite3
import logging
import random
import math
from datetime import datetime, timedelta
import asyncio
import json
import os

logger = logging.getLogger(__name__)

class QuantumProgression(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db_path = 'quantum_levels.db'
        self.level_config = self.load_level_config()
        self.cooldowns = {}  # XP cooldown tracking
        self.init_database()
        
        # Futuristic level themes
        self.quantum_tiers = {
            1: {'name': 'Initiate', 'icon': '◇', 'color': 0x00FFFF},
            5: {'name': 'Apprentice', 'icon': '◆', 'color': 0x00FF88},
            10: {'name': 'Adept', 'icon': '◈', 'color': 0xFF00FF},
            15: {'name': 'Specialist', 'icon': '◉', 'color': 0xFFAA00},
            20: {'name': 'Expert', 'icon': '⬢', 'color': 0xFF0040},
            25: {'name': 'Master', 'icon': '⬟', 'color': 0x8A2BE2},
            30: {'name': 'Grandmaster', 'icon': '◎', 'color': 0x7B68EE},
            50: {'name': 'Quantum Lord', 'icon': '⟐', 'color': 0xFFD700},
            75: {'name': 'Neural Overlord', 'icon': '⬢', 'color': 0xB22222},
            100: {'name': 'Cosmic Entity', 'icon': '◊', 'color': 0x9932CC}
        }
        
        # Progress bar elements
        self.holo_bars = {
            'empty': '▱',
            'filled': '▰',
            'quantum': '◈',
            'neural': '◉'
        }
    
    def get_quantum_tier(self, level):
        """Get quantum tier information for level"""
        tier_level = max([tier for tier in self.quantum_tiers.keys() if level >= tier])
        return self.quantum_tiers[tier_level]
    
    def create_holographic_progress_bar(self, current_xp, required_xp, length=20):
        """Create futuristic progress bar"""
        filled_length = int(length * current_xp / required_xp)
        bar = ""
        
        for i in range(length):
            if i < filled_length:
                if i % 4 == 0:
                    bar += self.holo_bars['quantum']
                elif i % 2 == 0:
                    bar += self.holo_bars['neural']
                else:
                    bar += self.holo_bars['filled']
            else:
                bar += self.holo_bars['empty']
        
        percentage = round((current_xp / required_xp) * 100, 1)
        return f"{bar} {percentage}%"
    
    def load_level_config(self):
        """Load leveling configuration"""
        default_config = {
            "enabled": True,
            "xp_per_message": [15, 25],  # Random range
            "xp_cooldown": 60,  # seconds
            "level_up_message": "⟨ Quantum evolution detected! {user} has achieved Neural Level {level}! ⟩",
            "level_up_channel": None,
            "level_roles": {},  # {level: role_name}
            "xp_multiplier": 1.0,
            "no_xp_channels": [],
            "no_xp_roles": []
        }
        
        try:
            if os.path.exists('level_config.json'):
                with open('level_config.json', 'r') as f:
                    config = json.load(f)
                    return {**default_config, **config}
        except Exception as e:
            logger.error(f"Error loading level config: {e}")
        
        return default_config
    
    def save_level_config(self):
        """Save leveling configuration"""
        try:
            with open('level_config.json', 'w') as f:
                json.dump(self.level_config, f, indent=4)
        except Exception as e:
            logger.error(f"Error saving level config: {e}")
    
    def init_database(self):
        """Initialize SQLite database for leveling"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS user_levels (
                    user_id INTEGER,
                    guild_id INTEGER,
                    xp INTEGER DEFAULT 0,
                    level INTEGER DEFAULT 0,
                    messages INTEGER DEFAULT 0,
                    last_message TIMESTAMP,
                    PRIMARY KEY (user_id, guild_id)
                )
            ''')
            
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"Error initializing leveling database: {e}")
    
    def calculate_level(self, xp: int) -> int:
        """Calculate level from XP using quadratic formula"""
        return int(math.sqrt(xp / 100))
    
    def calculate_xp_for_level(self, level: int) -> int:
        """Calculate XP required for a specific level"""
        return level * level * 100
    
    def get_user_data(self, user_id: int, guild_id: int):
        """Get user leveling data"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT xp, level, messages, last_message 
                FROM user_levels 
                WHERE user_id = ? AND guild_id = ?
            ''', (user_id, guild_id))
            
            result = cursor.fetchone()
            conn.close()
            
            if result:
                return {
                    'xp': result[0],
                    'level': result[1],
                    'messages': result[2],
                    'last_message': result[3]
                }
            return None
        except Exception as e:
            logger.error(f"Error getting user data: {e}")
            return None
    
    def update_user_data(self, user_id: int, guild_id: int, xp: int, level: int, messages: int):
        """Update user leveling data"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT OR REPLACE INTO user_levels 
                (user_id, guild_id, xp, level, messages, last_message)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (user_id, guild_id, xp, level, messages, datetime.utcnow()))
            
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"Error updating user data: {e}")
    
    async def give_level_role(self, member: discord.Member, level: int):
        """Give role rewards for leveling up"""
        try:
            level_roles = self.level_config.get("level_roles", {})
            role_name = level_roles.get(str(level))
            
            if role_name:
                role = discord.utils.get(member.guild.roles, name=role_name)
                if role and role not in member.roles:
                    await member.add_roles(role, reason=f"Level {level} reward")
                    return role
        except Exception as e:
            logger.error(f"Error giving level role: {e}")
        return None
    
    async def process_message(self, message):
        """Handle XP gain from messages (called by central handler)"""
        try:
            # Check if channel is blacklisted
            if message.channel.id in self.level_config.get("no_xp_channels", []):
                return
            
            # Check if user has blacklisted role
            no_xp_roles = self.level_config.get("no_xp_roles", [])
            if any(role.name in no_xp_roles for role in message.author.roles):
                return
            
            user_id = message.author.id
            guild_id = message.guild.id
            
            # Check cooldown
            cooldown_key = f"{user_id}_{guild_id}"
            cooldown_time = self.level_config.get("xp_cooldown", 60)
            
            if cooldown_key in self.cooldowns:
                if (datetime.utcnow() - self.cooldowns[cooldown_key]).total_seconds() < cooldown_time:
                    return
            
            self.cooldowns[cooldown_key] = datetime.utcnow()
            
            # Get current user data
            user_data = self.get_user_data(user_id, guild_id)
            if not user_data:
                user_data = {'xp': 0, 'level': 0, 'messages': 0}
            
            # Calculate XP gain
            xp_range = self.level_config.get("xp_per_message", [15, 25])
            xp_gain = random.randint(xp_range[0], xp_range[1])
            xp_gain = int(xp_gain * self.level_config.get("xp_multiplier", 1.0))
            
            # Update XP and messages
            new_xp = user_data['xp'] + xp_gain
            new_messages = user_data['messages'] + 1
            old_level = user_data['level']
            new_level = self.calculate_level(new_xp)
            
            # Update database
            self.update_user_data(user_id, guild_id, new_xp, new_level, new_messages)
            
            # Check for level up
            if new_level > old_level:
                await self.handle_level_up(message.author, message.channel, new_level)
                await self.give_level_role(message.author, new_level)
                
        except Exception as e:
            logger.error(f"Error in message XP handler: {e}")
    
    async def handle_level_up(self, member: discord.Member, channel: discord.TextChannel, level: int):
        """Handle level up events"""
        try:
            # Give level role if configured
            role = await self.give_level_role(member, level)
            
            # Send level up message
            level_up_message = self.level_config.get("level_up_message", 
                "🎉 Congratulations {user}! You've reached level **{level}**!")
            
            message = level_up_message.format(user=member.mention, level=level)
            
            # Check for custom level up channel
            level_channel_id = self.level_config.get("level_up_channel")
            if level_channel_id:
                level_channel = self.bot.get_channel(level_channel_id)
                if level_channel:
                    channel = level_channel
            
            embed = discord.Embed(
                title="🎉 Level Up!",
                description=message,
                color=discord.Color.gold(),
                timestamp=datetime.utcnow()
            )
            embed.set_thumbnail(url=member.display_avatar.url)
            
            if role:
                embed.add_field(name="Role Reward", value=role.mention, inline=False)
            
            await channel.send(embed=embed)
            
        except Exception as e:
            logger.error(f"Error handling level up: {e}")
    
    @commands.command(name='rank')
    async def show_rank(self, ctx, member: discord.Member = None):
        """Show user's rank and level"""
        if member is None:
            member = ctx.author
        
        user_data = self.get_user_data(member.id, ctx.guild.id)
        if not user_data:
            await ctx.send(f"{member.mention} hasn't gained any XP yet.")
            return
        
        current_level = user_data['level']
        current_xp = user_data['xp']
        xp_for_current = self.calculate_xp_for_level(current_level)
        xp_for_next = self.calculate_xp_for_level(current_level + 1)
        xp_progress = current_xp - xp_for_current
        xp_needed = xp_for_next - xp_for_current
        
        # Calculate rank
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                SELECT COUNT(*) + 1 FROM user_levels 
                WHERE guild_id = ? AND xp > ?
            ''', (ctx.guild.id, current_xp))
            rank = cursor.fetchone()[0]
            conn.close()
        except:
            rank = "Unknown"
        
        embed = discord.Embed(
            title=f"📊 {member.display_name}'s Rank",
            color=member.color,
            timestamp=datetime.utcnow()
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        
        embed.add_field(name="Level", value=current_level, inline=True)
        embed.add_field(name="Rank", value=f"#{rank}", inline=True)
        embed.add_field(name="Total XP", value=f"{current_xp:,}", inline=True)
        embed.add_field(name="Messages", value=f"{user_data['messages']:,}", inline=True)
        embed.add_field(name="Progress", value=f"{xp_progress}/{xp_needed} XP", inline=True)
        
        # Progress bar
        progress_percent = (xp_progress / xp_needed) * 100 if xp_needed > 0 else 100
        progress_bar = "█" * int(progress_percent / 10) + "░" * (10 - int(progress_percent / 10))
        embed.add_field(name="Progress Bar", value=f"`{progress_bar}` {progress_percent:.1f}%", inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='leaderboard', aliases=['lb'])
    async def show_leaderboard(self, ctx, page: int = 1):
        """Show server leaderboard"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT user_id, xp, level, messages 
                FROM user_levels 
                WHERE guild_id = ? 
                ORDER BY xp DESC 
                LIMIT 10 OFFSET ?
            ''', (ctx.guild.id, (page - 1) * 10))
            
            results = cursor.fetchall()
            conn.close()
            
            if not results:
                await ctx.send("No leaderboard data available.")
                return
            
            embed = discord.Embed(
                title=f"🏆 Leaderboard - Page {page}",
                color=discord.Color.gold(),
                timestamp=datetime.utcnow()
            )
            
            leaderboard_text = ""
            for i, (user_id, xp, level, messages) in enumerate(results, start=(page-1)*10+1):
                user = self.bot.get_user(user_id)
                username = user.display_name if user else f"Unknown User ({user_id})"
                
                medal = ""
                if i == 1:
                    medal = "🥇"
                elif i == 2:
                    medal = "🥈"
                elif i == 3:
                    medal = "🥉"
                
                leaderboard_text += f"{medal} **#{i}** {username}\n"
                leaderboard_text += f"Level {level} • {xp:,} XP • {messages:,} messages\n\n"
            
            embed.description = leaderboard_text
            await ctx.send(embed=embed)
            
        except Exception as e:
            logger.error(f"Error showing leaderboard: {e}")
            await ctx.send("Error retrieving leaderboard data.")
    
    @commands.command(name='givexp')
    @commands.has_permissions(administrator=True)
    async def give_xp(self, ctx, member: discord.Member, amount: int):
        """Give XP to a user"""
        user_data = self.get_user_data(member.id, ctx.guild.id)
        if not user_data:
            user_data = {'xp': 0, 'level': 0, 'messages': 0}
        
        old_level = user_data['level']
        new_xp = max(0, user_data['xp'] + amount)
        new_level = self.calculate_level(new_xp)
        
        self.update_user_data(member.id, ctx.guild.id, new_xp, new_level, user_data['messages'])
        
        embed = discord.Embed(
            title="✅ XP Updated",
            description=f"Gave {amount:,} XP to {member.mention}\nNew total: {new_xp:,} XP (Level {new_level})",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)
        
        # Handle level up if occurred
        if new_level > old_level:
            await self.handle_level_up(member, ctx.channel, new_level)
    
    @commands.command(name='level_config')
    @commands.has_permissions(administrator=True)
    async def show_level_config(self, ctx):
        """Show leveling configuration"""
        config = self.level_config
        
        embed = discord.Embed(
            title="⚙️ Leveling Configuration",
            color=discord.Color.blue()
        )
        
        embed.add_field(name="Enabled", value="✅" if config.get("enabled") else "❌", inline=True)
        embed.add_field(name="XP per Message", value=f"{config['xp_per_message'][0]}-{config['xp_per_message'][1]}", inline=True)
        embed.add_field(name="XP Cooldown", value=f"{config['xp_cooldown']}s", inline=True)
        embed.add_field(name="XP Multiplier", value=f"{config['xp_multiplier']}x", inline=True)
        
        level_channel = self.bot.get_channel(config.get("level_up_channel"))
        embed.add_field(name="Level Up Channel", value=level_channel.mention if level_channel else "Current channel", inline=True)
        
        level_roles = config.get("level_roles", {})
        if level_roles:
            roles_text = "\n".join([f"Level {level}: {role}" for level, role in level_roles.items()])
            embed.add_field(name="Level Roles", value=roles_text[:1024], inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='level_toggle')
    @commands.has_permissions(administrator=True)
    async def toggle_leveling(self, ctx):
        """Toggle leveling system"""
        self.level_config["enabled"] = not self.level_config.get("enabled", True)
        self.save_level_config()
        
        status = "enabled" if self.level_config["enabled"] else "disabled"
        embed = discord.Embed(
            title="✅ Leveling System Updated",
            description=f"Leveling system is now {status}.",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(QuantumProgression(bot))