import discord
from discord.ext import commands
import re
import logging
from datetime import datetime, timedelta
import json
import os

logger = logging.getLogger(__name__)

class AutoMod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.automod_config = self.load_automod_config()
        
    def load_automod_config(self):
        """Load automod configuration"""
        default_config = {
            "enabled": True,
            "anti_spam": {
                "enabled": True,
                "max_messages": 5,
                "time_window": 10,
                "punishment": "mute"
            },
            "anti_caps": {
                "enabled": True,
                "caps_threshold": 70,
                "min_length": 10,
                "punishment": "warn"
            },
            "anti_invite": {
                "enabled": True,
                "whitelist": [],
                "punishment": "delete"
            },
            "bad_words": {
                "enabled": True,
                "words": ["spam", "scam"],
                "punishment": "warn"
            },
            "anti_mention": {
                "enabled": True,
                "max_mentions": 5,
                "punishment": "warn"
            },
            "link_filter": {
                "enabled": False,
                "whitelist": ["discord.gg", "youtube.com", "github.com"],
                "punishment": "delete"
            }
        }
        
        try:
            if os.path.exists('automod_config.json'):
                with open('automod_config.json', 'r') as f:
                    config = json.load(f)
                    return {**default_config, **config}
        except Exception as e:
            logger.error(f"Error loading automod config: {e}")
        
        return default_config
    
    def save_automod_config(self):
        """Save automod configuration"""
        try:
            with open('automod_config.json', 'w') as f:
                json.dump(self.automod_config, f, indent=4)
        except Exception as e:
            logger.error(f"Error saving automod config: {e}")
    
    def check_spam(self, message):
        """Check for spam messages"""
        config = self.automod_config["anti_spam"]
        if not config["enabled"]:
            return False
        
        # Implementation would track message frequency per user
        # For simplicity, checking if message is repeated
        return False
    
    def check_caps(self, message):
        """Check for excessive caps"""
        config = self.automod_config["anti_caps"]
        if not config["enabled"] or len(message.content) < config["min_length"]:
            return False
        
        caps_count = sum(1 for c in message.content if c.isupper())
        caps_percentage = (caps_count / len(message.content)) * 100
        
        return caps_percentage > config["caps_threshold"]
    
    def check_invites(self, message):
        """Check for Discord invites"""
        config = self.automod_config["anti_invite"]
        if not config["enabled"]:
            return False
        
        invite_pattern = r'discord\.gg/[a-zA-Z0-9]+'
        invites = re.findall(invite_pattern, message.content)
        
        for invite in invites:
            if invite not in config["whitelist"]:
                return True
        return False
    
    def check_bad_words(self, message):
        """Check for bad words"""
        config = self.automod_config["bad_words"]
        if not config["enabled"]:
            return False
        
        content_lower = message.content.lower()
        return any(word in content_lower for word in config["words"])
    
    def check_mentions(self, message):
        """Check for excessive mentions"""
        config = self.automod_config["anti_mention"]
        if not config["enabled"]:
            return False
        
        mention_count = len(message.mentions) + len(message.role_mentions)
        return mention_count > config["max_mentions"]
    
    def check_links(self, message):
        """Check for unauthorized links"""
        config = self.automod_config["link_filter"]
        if not config["enabled"]:
            return False
        
        url_pattern = r'https?://[^\s]+'
        urls = re.findall(url_pattern, message.content)
        
        for url in urls:
            if not any(domain in url for domain in config["whitelist"]):
                return True
        return False
    
    async def apply_punishment(self, message, violation_type):
        """Apply punishment based on violation"""
        try:
            config = self.automod_config[violation_type]
            punishment = config.get("punishment", "warn")
            
            if punishment == "delete":
                await message.delete()
                await message.channel.send(f"{message.author.mention}, your message was deleted for violating server rules.", delete_after=5)
            
            elif punishment == "warn":
                # Get moderation cog for warning
                mod_cog = self.bot.get_cog("Moderation")
                if mod_cog:
                    await mod_cog.warn_member(message, message.author, reason=f"AutoMod: {violation_type}")
            
            elif punishment == "mute":
                # Get moderation cog for muting
                mod_cog = self.bot.get_cog("Moderation")
                if mod_cog:
                    await mod_cog.mute_member(message, message.author, duration=10, reason=f"AutoMod: {violation_type}")
            
        except Exception as e:
            logger.error(f"Error applying punishment: {e}")
    
    async def process_message(self, message):
        """Monitor messages for automod violations (called by central handler)"""
        try:
            # Skip if user has manage messages permission
            if message.author.guild_permissions.manage_messages:
                return
            
            # Check various violations
            violations = []
            
            if self.check_spam(message):
                violations.append("anti_spam")
            
            if self.check_caps(message):
                violations.append("anti_caps")
            
            if self.check_invites(message):
                violations.append("anti_invite")
            
            if self.check_bad_words(message):
                violations.append("bad_words")
            
            if self.check_mentions(message):
                violations.append("anti_mention")
            
            if self.check_links(message):
                violations.append("link_filter")
            
            # Apply punishments
            for violation in violations:
                await self.apply_punishment(message, violation)
                break  # Only apply first violation to avoid spam
            
        except Exception as e:
            logger.error(f"Error in automod message handler: {e}")
    
    @commands.command(name='automod_config')
    @commands.has_permissions(manage_guild=True)
    async def show_automod_config(self, ctx):
        """Show automod configuration"""
        config = self.automod_config
        
        embed = discord.Embed(
            title="🤖 AutoMod Configuration",
            color=discord.Color.blue()
        )
        
        embed.add_field(name="Status", value="✅ Enabled" if config.get("enabled") else "❌ Disabled", inline=False)
        
        for feature, settings in config.items():
            if isinstance(settings, dict) and "enabled" in settings:
                status = "✅" if settings["enabled"] else "❌"
                embed.add_field(name=feature.replace('_', ' ').title(), value=status, inline=True)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='automod_toggle')
    @commands.has_permissions(manage_guild=True)
    async def toggle_automod(self, ctx, feature: str = None):
        """Toggle automod features"""
        if feature is None:
            # Toggle main automod
            self.automod_config["enabled"] = not self.automod_config.get("enabled", True)
            status = "enabled" if self.automod_config["enabled"] else "disabled"
            await ctx.send(f"AutoMod is now {status}.")
        else:
            # Toggle specific feature
            if feature in self.automod_config and isinstance(self.automod_config[feature], dict):
                self.automod_config[feature]["enabled"] = not self.automod_config[feature].get("enabled", True)
                status = "enabled" if self.automod_config[feature]["enabled"] else "disabled"
                await ctx.send(f"AutoMod {feature.replace('_', ' ')} is now {status}.")
            else:
                await ctx.send("Invalid feature. Available: anti_spam, anti_caps, anti_invite, bad_words, anti_mention, link_filter")
        
        self.save_automod_config()
    
    @commands.command(name='add_badword')
    @commands.has_permissions(manage_guild=True)
    async def add_bad_word(self, ctx, *, word: str):
        """Add word to bad words filter"""
        if word.lower() not in self.automod_config["bad_words"]["words"]:
            self.automod_config["bad_words"]["words"].append(word.lower())
            self.save_automod_config()
            await ctx.send(f"Added '{word}' to bad words filter.")
        else:
            await ctx.send("Word already in filter.")
    
    @commands.command(name='remove_badword')
    @commands.has_permissions(manage_guild=True)
    async def remove_bad_word(self, ctx, *, word: str):
        """Remove word from bad words filter"""
        if word.lower() in self.automod_config["bad_words"]["words"]:
            self.automod_config["bad_words"]["words"].remove(word.lower())
            self.save_automod_config()
            await ctx.send(f"Removed '{word}' from bad words filter.")
        else:
            await ctx.send("Word not in filter.")

async def setup(bot):
    await bot.add_cog(AutoMod(bot))