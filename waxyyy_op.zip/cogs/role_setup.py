import discord
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)

class RoleSetup(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name='setup_staff_role')
    @commands.has_permissions(administrator=True)
    async def setup_staff_role(self, ctx):
        """Create the PygStaff.in ♡ role with appropriate permissions"""
        try:
            # Check if role already exists
            existing_role = discord.utils.get(ctx.guild.roles, name="PygStaff.in ♡")
            if existing_role:
                embed = discord.Embed(
                    title="ℹ️ Role Already Exists",
                    description=f"The {existing_role.mention} role already exists.",
                    color=discord.Color.blue()
                )
                await ctx.send(embed=embed)
                return
            
            # Create the STAFF TEAM role with appropriate permissions
            staff_permissions = discord.Permissions(
                manage_messages=True,
                kick_members=True,
                ban_members=True,
                manage_roles=True,
                manage_channels=True,
                view_audit_log=True,
                moderate_members=True,
                send_messages=True,
                embed_links=True,
                attach_files=True,
                read_message_history=True,
                mention_everyone=True,
                use_external_emojis=True,
                add_reactions=True
            )
            
            role = await ctx.guild.create_role(
                name="PygStaff.in ♡",
                permissions=staff_permissions,
                color=discord.Color.green(),
                hoist=True,
                mentionable=True,
                reason=f"Staff role created by {ctx.author}"
            )
            
            embed = discord.Embed(
                title="✅ PygStaff.in ♡ Role Created",
                description=f"Successfully created {role.mention} with moderation permissions.",
                color=discord.Color.green()
            )
            embed.add_field(
                name="Permissions Granted",
                value="• Manage Messages\n• Kick/Ban Members\n• Manage Roles\n• Manage Channels\n• View Audit Log\n• Moderate Members",
                inline=False
            )
            embed.add_field(
                name="Next Steps",
                value="Use `!addrole @user PygStaff.in ♡` to assign this role to staff members.",
                inline=False
            )
            
            await ctx.send(embed=embed)
            
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to create roles.")
        except Exception as e:
            logger.error(f"Error creating staff role: {e}")
            await ctx.send("❌ Failed to create staff role.")

async def setup(bot):
    await bot.add_cog(RoleSetup(bot))