import discord
from discord.ext import commands, tasks
import sqlite3
import logging
import json
import os
from datetime import datetime, timedelta, time
import asyncio

logger = logging.getLogger(__name__)

class StaffReports(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db_path = 'staff_reports.db'
        self.reports_config = self.load_reports_config()
        self.init_database()
        self.daily_reminder.start()
    
    def load_reports_config(self):
        """Load staff reports configuration"""
        default_config = {
            "enabled": True,
            "reminder_time": "21:00",  # 24-hour format (9 PM)
            "staff_roles": ["PygStaff.in ♡", "Moderator", "Admin"],
            "report_channel": None,
            "summary_channel": None,
            "report_template": {
                "questions": [
                    "What tasks did you complete today?",
                    "Any issues or concerns to report?",
                    "Goals for tomorrow?",
                    "Additional comments (optional)"
                ]
            },
            "auto_summary": True,
            "reminder_message": "🌙 Daily staff report reminder! रात 9 बजे - कृपया अपनी दैनिक रिपोर्ट जमा करें। Please submit your daily report using `!report` command.",
            "notification_settings": {
                "send_dm": True,
                "send_channel_notification": True,
                "reminder_hours_before": [2, 1],
                "follow_up_after_minutes": 30
            }
        }
        
        try:
            if os.path.exists('staff_reports_config.json'):
                with open('staff_reports_config.json', 'r') as f:
                    config = json.load(f)
                    return {**default_config, **config}
        except Exception as e:
            logger.error(f"Error loading staff reports config: {e}")
        
        return default_config
    
    def save_reports_config(self):
        """Save staff reports configuration"""
        try:
            with open('staff_reports_config.json', 'w') as f:
                json.dump(self.reports_config, f, indent=4)
        except Exception as e:
            logger.error(f"Error saving staff reports config: {e}")
    
    def init_database(self):
        """Initialize SQLite database for staff reports"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS staff_reports (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    guild_id INTEGER NOT NULL,
                    report_date DATE NOT NULL,
                    answers TEXT NOT NULL,
                    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    status TEXT DEFAULT 'submitted'
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS staff_assignments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    guild_id INTEGER NOT NULL,
                    assigned_by INTEGER NOT NULL,
                    task_title TEXT NOT NULL,
                    task_description TEXT,
                    assigned_date DATE NOT NULL,
                    due_date DATE,
                    status TEXT DEFAULT 'pending',
                    priority TEXT DEFAULT 'medium',
                    notes TEXT
                )
            ''')
            
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"Error initializing staff reports database: {e}")
    
    def is_staff_member(self, member: discord.Member) -> bool:
        """Check if member has staff role"""
        staff_roles = self.reports_config.get("staff_roles", [])
        return any(role.name in staff_roles for role in member.roles)
    
    def get_staff_members(self, guild: discord.Guild) -> list:
        """Get all staff members in guild"""
        staff_roles = self.reports_config.get("staff_roles", [])
        staff_members = []
        
        for member in guild.members:
            if any(role.name in staff_roles for role in member.roles):
                staff_members.append(member)
        
        return staff_members
    
    def has_submitted_today(self, user_id: int, guild_id: int) -> bool:
        """Check if user has submitted report today"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            today = datetime.now().date()
            cursor.execute('''
                SELECT COUNT(*) FROM staff_reports 
                WHERE user_id = ? AND guild_id = ? AND report_date = ?
            ''', (user_id, guild_id, today))
            
            count = cursor.fetchone()[0]
            conn.close()
            return count > 0
        except Exception as e:
            logger.error(f"Error checking today's report: {e}")
            return False
    
    @tasks.loop(minutes=1)
    async def daily_reminder(self):
        """Enhanced daily report reminder system with multiple notifications"""
        try:
            if not self.reports_config.get("enabled", True):
                return
            
            now = datetime.now()
            current_time = now.time()
            reminder_time = datetime.strptime(self.reports_config.get("reminder_time", "21:00"), "%H:%M").time()
            notification_settings = self.reports_config.get("notification_settings", {})
            
            # Main reminder at specified time (9 PM)
            if abs((datetime.combine(datetime.today(), current_time) - 
                   datetime.combine(datetime.today(), reminder_time)).total_seconds()) <= 60:
                await self.send_main_reminder()
            
            # Pre-reminders (2 hours and 1 hour before)
            reminder_hours = notification_settings.get("reminder_hours_before", [2, 1])
            for hours_before in reminder_hours:
                pre_reminder_time = (datetime.combine(datetime.today(), reminder_time) - 
                                   timedelta(hours=hours_before)).time()
                
                if abs((datetime.combine(datetime.today(), current_time) - 
                       datetime.combine(datetime.today(), pre_reminder_time)).total_seconds()) <= 60:
                    await self.send_pre_reminder(hours_before)
            
            # Follow-up reminder (30 minutes after main reminder)
            follow_up_minutes = notification_settings.get("follow_up_after_minutes", 30)
            follow_up_time = (datetime.combine(datetime.today(), reminder_time) + 
                            timedelta(minutes=follow_up_minutes)).time()
            
            if abs((datetime.combine(datetime.today(), current_time) - 
                   datetime.combine(datetime.today(), follow_up_time)).total_seconds()) <= 60:
                await self.send_follow_up_reminder()
                
        except Exception as e:
            logger.error(f"Error in daily reminder system: {e}")
    
    async def send_main_reminder(self):
        """Send main 9 PM reminder to all staff"""
        for guild in self.bot.guilds:
            staff_members = self.get_staff_members(guild)
            pending_staff = [member for member in staff_members 
                           if not self.has_submitted_today(member.id, guild.id)]
            
            if not pending_staff:
                continue
                
            # Send DM notifications
            if self.reports_config.get("notification_settings", {}).get("send_dm", True):
                for member in pending_staff:
                    await self.send_dm_reminder(member, guild, "main")
            
            # Send channel notification
            if self.reports_config.get("notification_settings", {}).get("send_channel_notification", True):
                await self.send_channel_notification(guild, pending_staff, "main")
    
    async def send_pre_reminder(self, hours_before):
        """Send pre-reminder notifications"""
        for guild in self.bot.guilds:
            staff_members = self.get_staff_members(guild)
            pending_staff = [member for member in staff_members 
                           if not self.has_submitted_today(member.id, guild.id)]
            
            if not pending_staff:
                continue
                
            for member in pending_staff:
                try:
                    embed = discord.Embed(
                        title="⏰ Staff Report Pre-Reminder",
                        description=f"🕘 **{hours_before} घंटे बाकी!** Staff report submission में {hours_before} hours remaining!",
                        color=discord.Color.orange()
                    )
                    embed.add_field(
                        name="Reminder",
                        value=f"Staff report submission time: 9:00 PM\nServer: {guild.name}",
                        inline=False
                    )
                    embed.add_field(
                        name="Action",
                        value="Get ready to submit your daily report using `!report`",
                        inline=False
                    )
                    await member.send(embed=embed)
                except discord.Forbidden:
                    pass
    
    async def send_follow_up_reminder(self):
        """Send follow-up reminder for pending submissions"""
        for guild in self.bot.guilds:
            staff_members = self.get_staff_members(guild)
            still_pending = [member for member in staff_members 
                           if not self.has_submitted_today(member.id, guild.id)]
            
            if not still_pending:
                continue
                
            for member in still_pending:
                try:
                    embed = discord.Embed(
                        title="🚨 Urgent: Staff Report Missing",
                        description="⚠️ **अभी भी रिपोर्ट जमा नहीं हुई!** Your daily report is still pending!",
                        color=discord.Color.red()
                    )
                    embed.add_field(
                        name="Status",
                        value="30 minutes have passed since the deadline",
                        inline=False
                    )
                    embed.add_field(
                        name="Immediate Action Required",
                        value=f"Please submit your report ASAP using `!report` in {guild.name}",
                        inline=False
                    )
                    await member.send(embed=embed)
                except discord.Forbidden:
                    pass
    
    async def send_dm_reminder(self, member, guild, reminder_type):
        """Send DM reminder to staff member"""
        try:
            if reminder_type == "main":
                embed = discord.Embed(
                    title="🌙 Daily Staff Report - Time to Submit!",
                    description=self.reports_config.get("reminder_message"),
                    color=discord.Color.blue()
                )
                embed.add_field(
                    name="⏰ समय हो गया! Time's Up!",
                    value=f"रात 9 बजे - अपनी दैनिक रिपोर्ट जमा करें\n9:00 PM - Submit your daily report now!",
                    inline=False
                )
                embed.add_field(
                    name="Command",
                    value=f"Use `!report` in {guild.name}",
                    inline=False
                )
                embed.set_footer(text="WaxYyy Database ♡ Staff Management System")
            
            await member.send(embed=embed)
        except discord.Forbidden:
            logger.warning(f"Could not send DM to {member.display_name} - DMs disabled")
    
    async def send_channel_notification(self, guild, pending_staff, reminder_type):
        """Send channel notification about pending reports"""
        try:
            report_channel_id = self.reports_config.get("report_channel")
            if not report_channel_id:
                # Try to find a general channel
                channel = discord.utils.get(guild.text_channels, name="general") or guild.text_channels[0]
            else:
                channel = self.bot.get_channel(report_channel_id)
            
            if not channel:
                return
                
            if reminder_type == "main":
                pending_mentions = " ".join([member.mention for member in pending_staff[:10]])
                
                embed = discord.Embed(
                    title="📋 Daily Staff Report Reminder",
                    description="🌙 **9:00 PM - Staff Report Time!**",
                    color=discord.Color.blue()
                )
                embed.add_field(
                    name="Pending Submissions",
                    value=f"{len(pending_staff)} staff members need to submit reports",
                    inline=False
                )
                embed.add_field(
                    name="Staff Members",
                    value=pending_mentions if len(pending_staff) <= 10 else f"{pending_mentions} +{len(pending_staff)-10} more",
                    inline=False
                )
                embed.add_field(
                    name="How to Submit",
                    value="Use `!report` command to submit your daily report",
                    inline=False
                )
                embed.set_footer(text="Daily reports help maintain team productivity and communication")
                
                await channel.send(embed=embed)
                
        except Exception as e:
            logger.error(f"Error sending channel notification: {e}")
    
    @daily_reminder.before_loop
    async def before_daily_reminder(self):
        """Wait for bot to be ready before starting reminder loop"""
        await self.bot.wait_until_ready()
    
    @commands.command(name='report')
    async def submit_report(self, ctx):
        """Submit daily staff report"""
        if not self.is_staff_member(ctx.author):
            await ctx.send("❌ This command is only available to staff members.")
            return
        
        if self.has_submitted_today(ctx.author.id, ctx.guild.id):
            await ctx.send("✅ You have already submitted your report for today.")
            return
        
        questions = self.reports_config["report_template"]["questions"]
        answers = []
        
        embed = discord.Embed(
            title="📋 Daily Staff Report",
            description="Please answer the following questions. Type your answer and press Enter for each question.",
            color=discord.Color.blue()
        )
        await ctx.send(embed=embed)
        
        for i, question in enumerate(questions, 1):
            embed = discord.Embed(
                title=f"Question {i}/{len(questions)}",
                description=question,
                color=discord.Color.orange()
            )
            await ctx.send(embed=embed)
            
            def check(m):
                return m.author == ctx.author and m.channel == ctx.channel
            
            try:
                response = await self.bot.wait_for('message', check=check, timeout=300)
                answers.append(response.content)
            except asyncio.TimeoutError:
                await ctx.send("⏰ Report submission timed out. Please try again.")
                return
        
        # Save report to database
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO staff_reports (user_id, guild_id, report_date, answers)
                VALUES (?, ?, ?, ?)
            ''', (ctx.author.id, ctx.guild.id, datetime.now().date(), json.dumps(answers)))
            
            conn.commit()
            conn.close()
            
            # Send confirmation
            embed = discord.Embed(
                title="✅ Report Submitted",
                description="Your daily staff report has been submitted successfully!",
                color=discord.Color.green(),
                timestamp=datetime.utcnow()
            )
            await ctx.send(embed=embed)
            
            # Send to report channel if configured
            report_channel_id = self.reports_config.get("report_channel")
            if report_channel_id:
                report_channel = self.bot.get_channel(report_channel_id)
                if report_channel:
                    await self.send_report_to_channel(report_channel, ctx.author, questions, answers)
            
        except Exception as e:
            logger.error(f"Error saving report: {e}")
            await ctx.send("❌ Failed to submit report. Please try again.")
    
    async def send_report_to_channel(self, channel, author, questions, answers):
        """Send formatted report to designated channel"""
        embed = discord.Embed(
            title=f"📋 Staff Report - {author.display_name}",
            color=discord.Color.blue(),
            timestamp=datetime.utcnow()
        )
        embed.set_thumbnail(url=author.display_avatar.url)
        
        for question, answer in zip(questions, answers):
            embed.add_field(name=question, value=answer[:1024], inline=False)
        
        embed.set_footer(text=f"Submitted by {author}")
        await channel.send(embed=embed)
    
    @commands.command(name='assign_task')
    @commands.has_permissions(manage_guild=True)
    async def assign_task(self, ctx, member: discord.Member, priority: str = "medium", *, task_description: str):
        """Assign a task to staff member
        
        Priority levels: low, medium, high, urgent
        """
        if not self.is_staff_member(member):
            await ctx.send("❌ Can only assign tasks to staff members.")
            return
        
        if priority.lower() not in ["low", "medium", "high", "urgent"]:
            priority = "medium"
        
        # Extract title (first line) and description
        lines = task_description.split('\n')
        title = lines[0][:100]  # Limit title length
        description = '\n'.join(lines[1:]) if len(lines) > 1 else ""
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO staff_assignments 
                (user_id, guild_id, assigned_by, task_title, task_description, assigned_date, priority)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (member.id, ctx.guild.id, ctx.author.id, title, description, 
                  datetime.now().date(), priority.lower()))
            
            task_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            # Send confirmation
            embed = discord.Embed(
                title="✅ Task Assigned",
                description=f"Task assigned to {member.mention}",
                color=discord.Color.green()
            )
            embed.add_field(name="Task ID", value=f"#{task_id}", inline=True)
            embed.add_field(name="Priority", value=priority.capitalize(), inline=True)
            embed.add_field(name="Title", value=title, inline=False)
            if description:
                embed.add_field(name="Description", value=description[:1024], inline=False)
            
            await ctx.send(embed=embed)
            
            # Send DM to assigned member
            try:
                dm_embed = discord.Embed(
                    title="📋 New Task Assignment",
                    description=f"You have been assigned a new task in **{ctx.guild.name}**",
                    color=discord.Color.orange()
                )
                dm_embed.add_field(name="Task ID", value=f"#{task_id}", inline=True)
                dm_embed.add_field(name="Priority", value=priority.capitalize(), inline=True)
                dm_embed.add_field(name="Assigned by", value=ctx.author.display_name, inline=True)
                dm_embed.add_field(name="Title", value=title, inline=False)
                if description:
                    dm_embed.add_field(name="Description", value=description[:1024], inline=False)
                
                await member.send(embed=dm_embed)
            except discord.Forbidden:
                pass
            
        except Exception as e:
            logger.error(f"Error assigning task: {e}")
            await ctx.send("❌ Failed to assign task.")
    
    @commands.command(name='my_tasks')
    async def view_my_tasks(self, ctx):
        """View your assigned tasks"""
        if not self.is_staff_member(ctx.author):
            await ctx.send("❌ This command is only available to staff members.")
            return
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT id, task_title, priority, assigned_date, status 
                FROM staff_assignments 
                WHERE user_id = ? AND guild_id = ? AND status != 'completed'
                ORDER BY 
                    CASE priority 
                        WHEN 'urgent' THEN 1 
                        WHEN 'high' THEN 2 
                        WHEN 'medium' THEN 3 
                        WHEN 'low' THEN 4 
                    END,
                    assigned_date DESC
            ''', (ctx.author.id, ctx.guild.id))
            
            tasks = cursor.fetchall()
            conn.close()
            
            if not tasks:
                await ctx.send("📋 You have no pending tasks.")
                return
            
            embed = discord.Embed(
                title=f"📋 Your Tasks ({len(tasks)})",
                color=discord.Color.blue()
            )
            
            for task_id, title, priority, assigned_date, status in tasks:
                priority_emoji = {
                    'urgent': '🔴',
                    'high': '🟠', 
                    'medium': '🟡',
                    'low': '🟢'
                }.get(priority, '⚪')
                
                embed.add_field(
                    name=f"{priority_emoji} #{task_id} - {title}",
                    value=f"Priority: {priority.capitalize()}\nStatus: {status.capitalize()}\nAssigned: {assigned_date}",
                    inline=True
                )
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            logger.error(f"Error viewing tasks: {e}")
            await ctx.send("❌ Failed to retrieve tasks.")
    
    @commands.command(name='complete_task')
    async def complete_task(self, ctx, task_id: int):
        """Mark a task as completed"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Verify task belongs to user
            cursor.execute('''
                SELECT task_title FROM staff_assignments 
                WHERE id = ? AND user_id = ? AND guild_id = ?
            ''', (task_id, ctx.author.id, ctx.guild.id))
            
            result = cursor.fetchone()
            if not result:
                await ctx.send("❌ Task not found or not assigned to you.")
                conn.close()
                return
            
            # Mark as completed
            cursor.execute('''
                UPDATE staff_assignments 
                SET status = 'completed' 
                WHERE id = ?
            ''', (task_id,))
            
            conn.commit()
            conn.close()
            
            embed = discord.Embed(
                title="✅ Task Completed",
                description=f"Task #{task_id} - '{result[0]}' has been marked as completed.",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
            
        except Exception as e:
            logger.error(f"Error completing task: {e}")
            await ctx.send("❌ Failed to complete task.")
    
    @commands.command(name='staff_summary')
    @commands.has_permissions(manage_guild=True)
    async def daily_summary(self, ctx, date: str = None):
        """Generate daily staff report summary"""
        try:
            if date:
                report_date = datetime.strptime(date, "%Y-%m-%d").date()
            else:
                report_date = datetime.now().date()
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get all reports for the date
            cursor.execute('''
                SELECT user_id, answers, submitted_at 
                FROM staff_reports 
                WHERE guild_id = ? AND report_date = ?
                ORDER BY submitted_at
            ''', (ctx.guild.id, report_date))
            
            reports = cursor.fetchall()
            
            # Get staff members who haven't submitted
            staff_members = self.get_staff_members(ctx.guild)
            submitted_users = [report[0] for report in reports]
            missing_reports = [member for member in staff_members if member.id not in submitted_users]
            
            conn.close()
            
            embed = discord.Embed(
                title=f"📊 Daily Staff Summary - {report_date}",
                color=discord.Color.blue(),
                timestamp=datetime.utcnow()
            )
            
            embed.add_field(
                name="📈 Statistics",
                value=f"Reports Submitted: {len(reports)}\nStaff Members: {len(staff_members)}\nCompletion Rate: {len(reports)/len(staff_members)*100:.1f}%",
                inline=False
            )
            
            if missing_reports:
                missing_names = [member.display_name for member in missing_reports[:10]]
                embed.add_field(
                    name="❌ Missing Reports",
                    value="\n".join(missing_names),
                    inline=True
                )
            
            if reports:
                submitted_names = []
                for user_id, _, submitted_at in reports:
                    user = self.bot.get_user(user_id)
                    if user:
                        submitted_names.append(f"{user.display_name} ({submitted_at.split()[1][:5]})")
                
                embed.add_field(
                    name="✅ Submitted Reports",
                    value="\n".join(submitted_names[:10]),
                    inline=True
                )
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            logger.error(f"Error generating summary: {e}")
            await ctx.send("❌ Failed to generate summary.")
    
    @commands.command(name='staff_config')
    @commands.has_permissions(manage_guild=True)
    async def show_staff_config(self, ctx):
        """Show staff reports configuration"""
        config = self.reports_config
        notification_settings = config.get("notification_settings", {})
        
        embed = discord.Embed(
            title="⚙️ Staff Reports Configuration",
            color=discord.Color.blue()
        )
        
        embed.add_field(name="Enabled", value="✅" if config.get("enabled") else "❌", inline=True)
        embed.add_field(name="Reminder Time", value=f"{config.get('reminder_time')} (9:00 PM)", inline=True)
        embed.add_field(name="Staff Roles", value=", ".join(config.get("staff_roles", [])), inline=True)
        
        report_channel = self.bot.get_channel(config.get("report_channel"))
        embed.add_field(name="Report Channel", value=report_channel.mention if report_channel else "Auto-detect", inline=True)
        
        embed.add_field(name="Auto Summary", value="✅" if config.get("auto_summary") else "❌", inline=True)
        embed.add_field(name="Questions", value=str(len(config["report_template"]["questions"])), inline=True)
        
        # Notification settings
        embed.add_field(
            name="📱 Notification Settings",
            value=f"DM Notifications: {'✅' if notification_settings.get('send_dm') else '❌'}\n"
                  f"Channel Notifications: {'✅' if notification_settings.get('send_channel_notification') else '❌'}\n"
                  f"Pre-reminders: {', '.join(map(str, notification_settings.get('reminder_hours_before', [])))} hours before\n"
                  f"Follow-up: {notification_settings.get('follow_up_after_minutes', 30)} minutes after",
            inline=False
        )
        
        await ctx.send(embed=embed)
    
    @commands.command(name='set_report_time')
    @commands.has_permissions(administrator=True)
    async def set_report_time(self, ctx, time_24h: str):
        """Set the daily report reminder time (24-hour format)
        
        Usage: !set_report_time 21:00
        """
        try:
            # Validate time format
            datetime.strptime(time_24h, "%H:%M")
            
            self.reports_config["reminder_time"] = time_24h
            self.save_reports_config()
            
            embed = discord.Embed(
                title="✅ Report Time Updated",
                description=f"Daily staff report reminder set to: **{time_24h}**",
                color=discord.Color.green()
            )
            embed.add_field(
                name="Next Reminder",
                value=f"Staff will be notified at {time_24h} daily",
                inline=False
            )
            await ctx.send(embed=embed)
            
        except ValueError:
            await ctx.send("❌ Invalid time format. Use 24-hour format (HH:MM), example: 21:00")
    
    @commands.command(name='test_staff_reminder')
    @commands.has_permissions(administrator=True)
    async def test_staff_reminder(self, ctx):
        """Test the staff reminder system (admin only)"""
        await ctx.send("🔄 Testing staff reminder system...")
        
        # Send test reminders to all pending staff
        await self.send_main_reminder()
        
        embed = discord.Embed(
            title="✅ Test Completed",
            description="Staff reminder notifications have been sent to all pending staff members",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(StaffReports(bot))