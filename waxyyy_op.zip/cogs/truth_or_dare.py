import discord
from discord.ext import commands
import asyncio
import logging
import random
import json
import os
from datetime import datetime

logger = logging.getLogger(__name__)

class TruthOrDare(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.games = {}  # Active games per guild
        self.game_config_file = 'truth_or_dare_config.json'
        self.load_game_data()
        
        # Quantum-themed truth questions
        self.truth_questions = [
            "What's the most embarrassing thing you've done in a voice chat?",
            "If you could quantum teleport anywhere right now, where would you go?",
            "What's your most cringe Discord message you've ever sent?",
            "Which member of this server would you trust with your deepest secret?",
            "What's the weirdest thing you've searched for online recently?",
            "If you could read minds for one day, whose mind would you read first?",
            "What's your biggest fear about the future?",
            "If you were invisible for a day, what's the first thing you'd do?",
            "What's the most childish thing you still do?",
            "Which conspiracy theory do you secretly believe?",
            "What's your most irrational fear?",
            "If you could swap lives with anyone for a week, who would it be?",
            "What's the most rebellious thing you've ever done?",
            "What's your guilty pleasure that you're ashamed of?",
            "If you could erase one memory, what would it be?",
            "What's the worst lie you've ever told?",
            "Who was your first crush and do you still think about them?",
            "What's something you pretend to like but actually hate?",
            "If you could know the answer to any question, what would you ask?",
            "What's the most trouble you've ever gotten into?"
        ]
        
        # Quantum-themed dare challenges
        self.dare_challenges = [
            "Change your Discord status to something embarrassing for 10 minutes",
            "Send a voice message singing happy birthday to someone random",
            "Post an embarrassing childhood photo in this channel",
            "Do 20 push-ups and send a video as proof",
            "Text your crush and tell them you like them",
            "Change your Discord nickname to something silly for 1 hour",
            "Record yourself doing a weird dance and share it",
            "Call a random number and ask if their refrigerator is running",
            "Post the 5th photo in your camera roll",
            "Let someone else write your Discord status for 24 hours",
            "Eat something spicy and record your reaction",
            "Do your best impression of another server member",
            "Share your most embarrassing autocorrect fail",
            "Record yourself telling a dad joke in a serious voice",
            "Change your profile picture to something chosen by the group",
            "Send a random emoji to 5 people with no explanation",
            "Do 10 jumping jacks while saying 'I am a quantum warrior'",
            "Share your browser history from the last hour",
            "Record yourself attempting to lick your elbow",
            "Send a voice note of you speaking in a fake accent for 30 seconds"
        ]
    
    def load_game_data(self):
        """Load game configuration and custom questions"""
        if os.path.exists(self.game_config_file):
            try:
                with open(self.game_config_file, 'r') as f:
                    config = json.load(f)
                    if 'custom_truths' in config:
                        self.truth_questions.extend(config['custom_truths'])
                    if 'custom_dares' in config:
                        self.dare_challenges.extend(config['custom_dares'])
            except Exception as e:
                logger.error(f"Error loading game config: {e}")
    
    def save_game_data(self):
        """Save game configuration"""
        try:
            config = {
                'custom_truths': [],
                'custom_dares': [],
                'last_updated': datetime.now().isoformat()
            }
            with open(self.game_config_file, 'w') as f:
                json.dump(config, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving game config: {e}")
    
    @commands.group(name='tod', invoke_without_command=True)
    async def truth_or_dare_group(self, ctx):
        """Truth or Dare quantum game system"""
        await self.start_game(ctx)
    
    @truth_or_dare_group.command(name='start')
    async def start_game(self, ctx):
        """Start a new Truth or Dare game"""
        guild_id = ctx.guild.id
        
        if guild_id in self.games and self.games[guild_id]['active']:
            embed = self.bot.create_futuristic_embed(
                "QUANTUM GAME ALREADY ACTIVE",
                "⟨ Truth or Dare matrix is currently running ⟩",
                'warning'
            )
            await ctx.send(embed=embed)
            return
        
        # Initialize new game
        self.games[guild_id] = {
            'active': True,
            'channel': ctx.channel.id,
            'players': [],
            'current_player': None,
            'round': 0,
            'started_by': ctx.author.id
        }
        
        embed = self.bot.create_futuristic_embed(
            "⚡ QUANTUM TRUTH OR DARE INITIATED ⚡",
            "⟨ Holographic reality matrix activated ⟩",
            'quantum'
        )
        embed.add_field(
            name="⟨ GAME MECHANICS ⟩",
            value="```yaml\n"
                  "◇ React with ✅ to join the quantum matrix\n"
                  "◇ React with ❌ to leave the game\n"
                  "◇ React with 🎮 to start when ready\n"
                  "◇ Minimum 2 players required\n```",
            inline=False
        )
        embed.add_field(
            name="⟨ QUANTUM COMMANDS ⟩",
            value="```yaml\n"
                  "◇ !tod truth - Get a truth question\n"
                  "◇ !tod dare - Get a dare challenge\n"
                  "◇ !tod skip - Skip your turn (limited)\n"
                  "◇ !tod stop - End the game\n```",
            inline=False
        )
        
        message = await ctx.send(embed=embed)
        await message.add_reaction('✅')
        await message.add_reaction('❌')
        await message.add_reaction('🎮')
        
        self.games[guild_id]['message'] = message.id
    
    @truth_or_dare_group.command(name='truth')
    async def get_truth(self, ctx):
        """Get a truth question"""
        guild_id = ctx.guild.id
        
        if guild_id not in self.games or not self.games[guild_id]['active']:
            embed = self.bot.create_futuristic_embed(
                "NO ACTIVE GAME",
                "⟨ Start a game first with !tod start ⟩",
                'error'
            )
            await ctx.send(embed=embed, delete_after=5)
            return
        
        game = self.games[guild_id]
        if ctx.author.id not in game['players']:
            embed = self.bot.create_futuristic_embed(
                "UNAUTHORIZED ACCESS",
                "⟨ You must join the game matrix first ⟩",
                'error'
            )
            await ctx.send(embed=embed, delete_after=5)
            return
        
        truth = random.choice(self.truth_questions)
        
        embed = self.bot.create_futuristic_embed(
            "⟨ QUANTUM TRUTH PROTOCOL ⟩",
            f"⟨ Target: {ctx.author.mention} ⟩",
            'neural'
        )
        embed.add_field(
            name="⟨ TRUTH MATRIX SCAN ⟩",
            value=f"```yaml\n{truth}\n```",
            inline=False
        )
        embed.add_field(
            name="⟨ PROTOCOL STATUS ⟩",
            value="```ini\n[SCAN] Complete\n[TRUTH] Required\n[HONESTY] Mandatory\n```",
            inline=False
        )
        
        await ctx.send(embed=embed)
        game['round'] += 1
    
    @truth_or_dare_group.command(name='dare')
    async def get_dare(self, ctx):
        """Get a dare challenge"""
        guild_id = ctx.guild.id
        
        if guild_id not in self.games or not self.games[guild_id]['active']:
            embed = self.bot.create_futuristic_embed(
                "NO ACTIVE GAME",
                "⟨ Start a game first with !tod start ⟩",
                'error'
            )
            await ctx.send(embed=embed, delete_after=5)
            return
        
        game = self.games[guild_id]
        if ctx.author.id not in game['players']:
            embed = self.bot.create_futuristic_embed(
                "UNAUTHORIZED ACCESS",
                "⟨ You must join the game matrix first ⟩",
                'error'
            )
            await ctx.send(embed=embed, delete_after=5)
            return
        
        dare = random.choice(self.dare_challenges)
        
        embed = self.bot.create_futuristic_embed(
            "⟨ QUANTUM DARE PROTOCOL ⟩",
            f"⟨ Target: {ctx.author.mention} ⟩",
            'plasma'
        )
        embed.add_field(
            name="⟨ CHALLENGE MATRIX ACTIVATED ⟩",
            value=f"```yaml\n{dare}\n```",
            inline=False
        )
        embed.add_field(
            name="⟨ PROTOCOL STATUS ⟩",
            value="```ini\n[CHALLENGE] Active\n[COMPLETION] Required\n[COURAGE] Mandatory\n```",
            inline=False
        )
        
        await ctx.send(embed=embed)
        game['round'] += 1
    
    @truth_or_dare_group.command(name='stop')
    async def stop_game(self, ctx):
        """Stop the current game"""
        guild_id = ctx.guild.id
        
        if guild_id not in self.games or not self.games[guild_id]['active']:
            return
        
        game = self.games[guild_id]
        if ctx.author.id != game['started_by'] and not ctx.author.guild_permissions.manage_messages:
            embed = self.bot.create_futuristic_embed(
                "ACCESS DENIED",
                "⟨ Only game creator or moderators can terminate ⟩",
                'error'
            )
            await ctx.send(embed=embed, delete_after=5)
            return
        
        self.games[guild_id]['active'] = False
        
        embed = self.bot.create_futuristic_embed(
            "⟨ QUANTUM GAME TERMINATED ⟩",
            f"⟨ Matrix deactivated after {game['round']} rounds ⟩",
            'success'
        )
        embed.add_field(
            name="⟨ FINAL STATISTICS ⟩",
            value=f"```yaml\n"
                  f"◇ Total Players: {len(game['players'])}\n"
                  f"◇ Rounds Completed: {game['round']}\n"
                  f"◇ Game Duration: Active\n"
                  f"◇ Status: Successfully Terminated\n```",
            inline=False
        )
        
        await ctx.send(embed=embed)
    
    @truth_or_dare_group.command(name='players')
    async def show_players(self, ctx):
        """Show current players in the game"""
        guild_id = ctx.guild.id
        
        if guild_id not in self.games or not self.games[guild_id]['active']:
            embed = self.bot.create_futuristic_embed(
                "NO ACTIVE GAME",
                "⟨ No quantum matrix currently active ⟩",
                'error'
            )
            await ctx.send(embed=embed, delete_after=5)
            return
        
        game = self.games[guild_id]
        players = [ctx.guild.get_member(player_id).display_name for player_id in game['players'] if ctx.guild.get_member(player_id)]
        
        embed = self.bot.create_futuristic_embed(
            "⟨ QUANTUM MATRIX PARTICIPANTS ⟩",
            f"⟨ {len(players)} entities connected ⟩",
            'info'
        )
        
        if players:
            player_list = "\n".join([f"◇ {name}" for name in players])
            embed.add_field(
                name="⟨ ACTIVE PLAYERS ⟩",
                value=f"```yaml\n{player_list}\n```",
                inline=False
            )
        else:
            embed.add_field(
                name="⟨ MATRIX STATUS ⟩",
                value="```yaml\n◇ No players connected\n```",
                inline=False
            )
        
        embed.add_field(
            name="⟨ GAME STATISTICS ⟩",
            value=f"```yaml\n"
                  f"◇ Current Round: {game['round']}\n"
                  f"◇ Status: Active\n"
                  f"◇ Channel: #{ctx.channel.name}\n```",
            inline=False
        )
        
        await ctx.send(embed=embed)
    
    @commands.Cog.listener()
    async def on_reaction_add(self, reaction, user):
        """Handle game reactions"""
        if user.bot:
            return
        
        guild_id = reaction.message.guild.id
        if guild_id not in self.games:
            return
        
        game = self.games[guild_id]
        if reaction.message.id != game.get('message'):
            return
        
        if reaction.emoji == '✅':
            if user.id not in game['players']:
                game['players'].append(user.id)
                embed = self.bot.create_futuristic_embed(
                    "PLAYER JOINED MATRIX",
                    f"⟨ {user.mention} connected to quantum game ⟩",
                    'success'
                )
                await reaction.message.channel.send(embed=embed, delete_after=3)
        
        elif reaction.emoji == '❌':
            if user.id in game['players']:
                game['players'].remove(user.id)
                embed = self.bot.create_futuristic_embed(
                    "PLAYER LEFT MATRIX",
                    f"⟨ {user.mention} disconnected from quantum game ⟩",
                    'warning'
                )
                await reaction.message.channel.send(embed=embed, delete_after=3)
        
        elif reaction.emoji == '🎮':
            if len(game['players']) >= 2:
                embed = self.bot.create_futuristic_embed(
                    "⚡ QUANTUM GAME ACTIVATED ⚡",
                    f"⟨ {len(game['players'])} players in the matrix ⟩",
                    'success'
                )
                embed.add_field(
                    name="⟨ GAME INSTRUCTIONS ⟩",
                    value="```yaml\n"
                          "◇ Use !tod truth for truth questions\n"
                          "◇ Use !tod dare for dare challenges\n"
                          "◇ Use !tod players to see participants\n"
                          "◇ Use !tod stop to end the game\n```",
                    inline=False
                )
                await reaction.message.channel.send(embed=embed)
            else:
                embed = self.bot.create_futuristic_embed(
                    "INSUFFICIENT PLAYERS",
                    "⟨ Minimum 2 players required for quantum matrix ⟩",
                    'error'
                )
                await reaction.message.channel.send(embed=embed, delete_after=5)

async def setup(bot):
    await bot.add_cog(TruthOrDare(bot))