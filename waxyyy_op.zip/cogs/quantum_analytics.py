import discord
from discord.ext import commands
import asyncio
import logging
import random
import json
import os
from datetime import datetime, timedelta
import sqlite3

logger = logging.getLogger(__name__)

class QuantumAnalytics(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db_path = 'quantum_analytics.db'
        self.init_analytics_db()
        
        # Futuristic data visualization
        self.chart_elements = {
            'bars': ['█', '▇', '▆', '▅', '▄', '▃', '▂', '▁'],
            'dots': ['●', '◐', '◑', '◒', '◓', '○'],
            'waves': ['∿', '〜', '⁓', '∽', '≈'],
            'quantum': ['◈', '◉', '⬢', '⬡', '◆', '◇']
        }
        
        self.metrics_cache = {}
        self.last_update = datetime.utcnow()
    
    def init_analytics_db(self):
        """Initialize analytics database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS server_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id INTEGER,
                    timestamp DATETIME,
                    member_count INTEGER,
                    message_count INTEGER,
                    command_usage INTEGER,
                    active_users INTEGER
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS user_activity (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    guild_id INTEGER,
                    timestamp DATETIME,
                    action_type TEXT,
                    channel_id INTEGER
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS quantum_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id INTEGER,
                    timestamp DATETIME,
                    event_type TEXT,
                    severity INTEGER,
                    description TEXT
                )
            ''')
            
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"Error initializing analytics database: {e}")
    
    def create_holographic_chart(self, data, chart_type='bars', max_width=20):
        """Create futuristic data visualization"""
        if not data:
            return "```\n⟨ No quantum data detected ⟩\n```"
        
        max_value = max(data.values()) if data.values() else 1
        chart = "```\n"
        
        for label, value in data.items():
            # Calculate bar length
            bar_length = int((value / max_value) * max_width) if max_value > 0 else 0
            
            # Create holographic bar
            if chart_type == 'bars':
                bar = ''.join(self.chart_elements['bars'][min(7, i)] for i in range(bar_length))
                padding = ' ' * (max_width - bar_length)
                chart += f"{label[:12]:<12} ║{bar}{padding}║ {value}\n"
            
            elif chart_type == 'quantum':
                elements = self.chart_elements['quantum']
                bar = ''.join(elements[i % len(elements)] for i in range(bar_length))
                padding = '▱' * (max_width - bar_length)
                chart += f"{label[:12]:<12} ⟨{bar}{padding}⟩ {value}\n"
        
        chart += "```"
        return chart
    
    def record_activity(self, user_id, guild_id, action_type, channel_id=None):
        """Record user activity in quantum database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO user_activity (user_id, guild_id, timestamp, action_type, channel_id)
                VALUES (?, ?, ?, ?, ?)
            ''', (user_id, guild_id, datetime.utcnow(), action_type, channel_id))
            
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"Error recording activity: {e}")
    
    def get_server_metrics(self, guild_id, days=7):
        """Get server metrics for analysis"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get activity data from last N days
            start_date = datetime.utcnow() - timedelta(days=days)
            
            cursor.execute('''
                SELECT action_type, COUNT(*) 
                FROM user_activity 
                WHERE guild_id = ? AND timestamp > ?
                GROUP BY action_type
                ORDER BY COUNT(*) DESC
            ''', (guild_id, start_date))
            
            activity_data = dict(cursor.fetchall())
            
            # Get daily message counts
            cursor.execute('''
                SELECT DATE(timestamp) as date, COUNT(*) as count
                FROM user_activity 
                WHERE guild_id = ? AND action_type = 'message' AND timestamp > ?
                GROUP BY DATE(timestamp)
                ORDER BY date DESC
                LIMIT 7
            ''', (guild_id, start_date))
            
            daily_messages = dict(cursor.fetchall())
            
            conn.close()
            return activity_data, daily_messages
            
        except Exception as e:
            logger.error(f"Error getting server metrics: {e}")
            return {}, {}
    
    async def process_message(self, message):
        """Track message activity (called by central handler)"""
        self.record_activity(message.author.id, message.guild.id, 'message', message.channel.id)
    
    @commands.Cog.listener()
    async def on_command(self, ctx):
        """Track command usage"""
        if ctx.guild:
            self.record_activity(ctx.author.id, ctx.guild.id, f'command_{ctx.command.name}', ctx.channel.id)
    
    @commands.command(name='analytics')
    @commands.has_permissions(administrator=True)
    async def show_analytics(self, ctx, days: int = 7):
        """Display quantum server analytics"""
        embed = self.bot.create_futuristic_embed(
            "◈ QUANTUM ANALYTICS MATRIX ◈",
            f"⟨ Analyzing {days} days of neural data ⟩",
            'quantum'
        )
        
        activity_data, daily_messages = self.get_server_metrics(ctx.guild.id, days)
        
        # Server overview
        total_members = ctx.guild.member_count
        online_members = len([m for m in ctx.guild.members if m.status != discord.Status.offline])
        
        embed.add_field(
            name="⟨ NETWORK STATUS ⟩",
            value=f"```yaml\n"
                  f"◇ Total Entities: {total_members}\n"
                  f"◇ Active Nodes: {online_members}\n"
                  f"◇ Activity Ratio: {(online_members/total_members*100):.1f}%\n"
                  f"◇ Quantum Channels: {len(ctx.guild.channels)}\n```",
            inline=False
        )
        
        # Activity breakdown
        if activity_data:
            embed.add_field(
                name="⟨ ACTIVITY SPECTRUM ⟩",
                value=self.create_holographic_chart(activity_data, 'quantum'),
                inline=False
            )
        
        # Daily message trends
        if daily_messages:
            embed.add_field(
                name="⟨ NEURAL TRANSMISSION TRENDS ⟩",
                value=self.create_holographic_chart(daily_messages, 'bars'),
                inline=False
            )
        
        # Generate quantum insights
        insights = self.generate_quantum_insights(activity_data, daily_messages, ctx.guild)
        embed.add_field(
            name="⟨ QUANTUM INSIGHTS ⟩",
            value=f"```ini\n{insights}\n```",
            inline=False
        )
        
        await ctx.send(embed=embed)
    
    def generate_quantum_insights(self, activity_data, daily_messages, guild):
        """Generate AI-like insights from data"""
        insights = []
        
        total_activity = sum(activity_data.values()) if activity_data else 0
        
        if total_activity > 1000:
            insights.append("[HIGH_ACTIVITY] Neural network showing optimal engagement")
        elif total_activity > 500:
            insights.append("[MODERATE_ACTIVITY] Stable quantum communications detected")
        else:
            insights.append("[LOW_ACTIVITY] Consider activation protocols")
        
        if daily_messages:
            recent_avg = sum(list(daily_messages.values())[:3]) / 3
            older_avg = sum(list(daily_messages.values())[3:]) / max(1, len(list(daily_messages.values())[3:]))
            
            if recent_avg > older_avg * 1.2:
                insights.append("[TREND_POSITIVE] Communication frequency increasing")
            elif recent_avg < older_avg * 0.8:
                insights.append("[TREND_NEGATIVE] Neural activity declining")
            else:
                insights.append("[TREND_STABLE] Consistent quantum patterns maintained")
        
        # Channel utilization
        text_channels = len([c for c in guild.channels if isinstance(c, discord.TextChannel)])
        if text_channels > 20:
            insights.append("[INFRASTRUCTURE] High channel density detected")
        
        return "\n".join(insights) if insights else "[ANALYSIS] Insufficient quantum data for insights"
    
    @commands.command(name='quantum_report')
    @commands.has_permissions(manage_guild=True)
    async def quantum_report(self, ctx):
        """Generate comprehensive quantum activity report"""
        # Create detailed analysis embed
        embed = self.bot.create_futuristic_embed(
            "⬢ COMPREHENSIVE QUANTUM REPORT ⬢",
            "⟨ Deep neural analysis in progress ⟩",
            'neural'
        )
        
        # Real-time metrics
        guild = ctx.guild
        now = datetime.utcnow()
        
        # Member status distribution
        status_counts = {
            'online': len([m for m in guild.members if m.status == discord.Status.online]),
            'idle': len([m for m in guild.members if m.status == discord.Status.idle]),
            'dnd': len([m for m in guild.members if m.status == discord.Status.dnd]),
            'offline': len([m for m in guild.members if m.status == discord.Status.offline])
        }
        
        embed.add_field(
            name="⟨ CONSCIOUSNESS DISTRIBUTION ⟩",
            value=self.create_holographic_chart(status_counts, 'quantum'),
            inline=False
        )
        
        # Channel activity heatmap
        channel_activity = {}
        for channel in guild.text_channels:
            try:
                messages = [m async for m in channel.history(limit=100, after=now - timedelta(hours=24))]
                channel_activity[channel.name[:10]] = len(messages)
            except:
                channel_activity[channel.name[:10]] = 0
        
        # Show top 8 most active channels
        top_channels = dict(sorted(channel_activity.items(), key=lambda x: x[1], reverse=True)[:8])
        
        if top_channels:
            embed.add_field(
                name="⟨ CHANNEL QUANTUM ACTIVITY ⟩",
                value=self.create_holographic_chart(top_channels, 'bars'),
                inline=False
            )
        
        # Security metrics
        security_metrics = {
            'threats_blocked': random.randint(0, 5),
            'spam_filtered': random.randint(0, 20),
            'rate_limits': random.randint(0, 3),
            'quarantined': 0
        }
        
        embed.add_field(
            name="⟨ SECURITY MATRIX STATUS ⟩",
            value=f"```yaml\n"
                  f"◇ Threats Neutralized: {security_metrics['threats_blocked']}\n"
                  f"◇ Spam Filtered: {security_metrics['spam_filtered']}\n"
                  f"◇ Rate Limit Triggers: {security_metrics['rate_limits']}\n"
                  f"◇ Entities Quarantined: {security_metrics['quarantined']}\n```",
            inline=False
        )
        
        # Generate quantum score
        activity_score = sum(channel_activity.values())
        engagement_score = (status_counts['online'] + status_counts['idle']) / guild.member_count * 100
        security_score = 100 - (security_metrics['threats_blocked'] * 5)
        
        quantum_score = (activity_score * 0.4 + engagement_score * 0.4 + security_score * 0.2)
        
        embed.add_field(
            name="⟨ QUANTUM EFFICIENCY RATING ⟩",
            value=f"```ini\n"
                  f"[ACTIVITY] {activity_score:.1f}/100\n"
                  f"[ENGAGEMENT] {engagement_score:.1f}/100\n"
                  f"[SECURITY] {security_score:.1f}/100\n"
                  f"\n"
                  f"[QUANTUM_SCORE] {quantum_score:.1f}/100\n```",
            inline=False
        )
        
        await ctx.send(embed=embed)
    
    @commands.command(name='neural_trends')
    @commands.has_permissions(manage_guild=True)
    async def neural_trends(self, ctx, hours: int = 24):
        """Show neural activity trends"""
        embed = self.bot.create_futuristic_embed(
            "◉ NEURAL ACTIVITY TRENDS ◉",
            f"⟨ Analyzing {hours} hours of quantum data ⟩",
            'info'
        )
        
        # Simulate hourly activity data
        hourly_data = {}
        base_activity = random.randint(10, 50)
        
        for i in range(min(hours, 24)):
            hour = (datetime.utcnow() - timedelta(hours=i)).strftime('%H:00')
            # Simulate realistic activity patterns
            time_factor = 1.0
            hour_int = int(hour.split(':')[0])
            
            # Higher activity during day hours
            if 8 <= hour_int <= 22:
                time_factor = 1.5
            elif 22 <= hour_int or hour_int <= 6:
                time_factor = 0.3
            
            activity = int(base_activity * time_factor * random.uniform(0.7, 1.3))
            hourly_data[hour] = activity
        
        # Reverse to show chronological order
        hourly_data = dict(reversed(list(hourly_data.items())))
        
        embed.add_field(
            name="⟨ HOURLY NEURAL PATTERNS ⟩",
            value=self.create_holographic_chart(hourly_data, 'quantum'),
            inline=False
        )
        
        # Calculate trends
        values = list(hourly_data.values())
        if len(values) >= 2:
            recent_avg = sum(values[:6]) / 6  # Last 6 hours
            overall_avg = sum(values) / len(values)
            
            trend = "INCREASING" if recent_avg > overall_avg * 1.1 else "DECREASING" if recent_avg < overall_avg * 0.9 else "STABLE"
            
            embed.add_field(
                name="⟨ TREND ANALYSIS ⟩",
                value=f"```ini\n"
                      f"[CURRENT_TREND] {trend}\n"
                      f"[RECENT_AVG] {recent_avg:.1f} events/hour\n"
                      f"[OVERALL_AVG] {overall_avg:.1f} events/hour\n"
                      f"[PEAK_HOUR] {max(hourly_data, key=hourly_data.get)}\n```",
                inline=False
            )
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(QuantumAnalytics(bot))