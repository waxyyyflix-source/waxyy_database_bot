import discord
from discord.ext import commands
import logging
import json
import os

logger = logging.getLogger(__name__)

class ProfileThemes(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.theme_config = self.load_theme_config()
        
        # Discord profile themes with avatars and banners
        self.profile_themes = {
            "quantum": {
                "name": "🔮 Quantum Matrix",
                "avatar": "https://cdn.discordapp.com/attachments/example/quantum_avatar.gif",
                "banner": "https://cdn.discordapp.com/attachments/example/quantum_banner.gif",
                "status": "🔮 Quantum Matrix Online",
                "description": "Holographic quantum effects with cyan energy flows"
            },
            "cyber": {
                "name": "⚡ Cyber Neon", 
                "avatar": "https://cdn.discordapp.com/attachments/example/cyber_avatar.gif",
                "banner": "https://cdn.discordapp.com/attachments/example/cyber_banner.gif",
                "status": "⚡ Cyber Mode Activated",
                "description": "Purple neon cyberpunk aesthetic"
            },
            "fire": {
                "name": "🔥 Fire Storm",
                "avatar": "https://cdn.discordapp.com/attachments/example/fire_avatar.gif", 
                "banner": "https://cdn.discordapp.com/attachments/example/fire_banner.gif",
                "status": "🔥 Fire Storm Mode",
                "description": "Intense orange and red flames"
            },
            "ice": {
                "name": "❄️ Ice Crystal",
                "avatar": "https://cdn.discordapp.com/attachments/example/ice_avatar.gif",
                "banner": "https://cdn.discordapp.com/attachments/example/ice_banner.gif", 
                "status": "❄️ Ice Crystal Theme",
                "description": "Cool blue and white crystal effects"
            },
            "dark": {
                "name": "🖤 Dark Void",
                "avatar": "https://cdn.discordapp.com/attachments/example/dark_avatar.gif",
                "banner": "https://cdn.discordapp.com/attachments/example/dark_banner.gif",
                "status": "🖤 Dark Void Active", 
                "description": "Deep black with purple accents"
            },
            "rainbow": {
                "name": "🌈 Rainbow Pride",
                "avatar": "https://cdn.discordapp.com/attachments/example/rainbow_avatar.gif",
                "banner": "https://cdn.discordapp.com/attachments/example/rainbow_banner.gif",
                "status": "🌈 Rainbow Theme",
                "description": "Vibrant rainbow gradient effects"
            }
        }
    
    def load_theme_config(self):
        """Load profile theme configuration"""
        default_config = {
            "enabled": True,
            "current_theme": "quantum",
            "auto_change_interval": 0,  # 0 = disabled, minutes for auto theme rotation
            "allowed_users": [1359130706634215678]  # w4xyyy can change themes
        }
        
        try:
            if os.path.exists('profile_config.json'):
                with open('profile_config.json', 'r') as f:
                    config = json.load(f)
                    return {**default_config, **config}
        except Exception as e:
            logger.error(f"Error loading profile config: {e}")
        
        return default_config
    
    def save_theme_config(self):
        """Save profile theme configuration"""
        try:
            with open('profile_config.json', 'w') as f:
                json.dump(self.theme_config, f, indent=4)
        except Exception as e:
            logger.error(f"Error saving profile config: {e}")
    
    async def apply_profile_theme(self, theme_name):
        """Apply a complete profile theme to the bot"""
        if theme_name not in self.profile_themes:
            return False, "Theme not found"
        
        theme = self.profile_themes[theme_name]
        success_count = 0
        total_operations = 3
        
        try:
            # Update bot status
            activity = discord.Activity(
                type=discord.ActivityType.watching,
                name=theme["status"]
            )
            await self.bot.change_presence(activity=activity, status=discord.Status.online)
            success_count += 1
            
            # Update avatar
            try:
                import aiohttp
                timeout = aiohttp.ClientTimeout(total=30)
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.get(theme["avatar"]) as response:
                        if response.status == 200:
                            avatar_data = await response.read()
                            if len(avatar_data) <= 10 * 1024 * 1024:  # 10MB limit
                                await self.bot.user.edit(avatar=avatar_data)
                                success_count += 1
            except Exception as e:
                logger.error(f"Avatar update failed: {e}")
            
            # Update banner
            try:
                import aiohttp
                timeout = aiohttp.ClientTimeout(total=30)
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.get(theme["banner"]) as response:
                        if response.status == 200:
                            banner_data = await response.read()
                            if len(banner_data) <= 10 * 1024 * 1024:  # 10MB limit
                                await self.bot.user.edit(banner=banner_data)
                                success_count += 1
            except Exception as e:
                logger.error(f"Banner update failed: {e}")
            
            # Save current theme
            self.theme_config["current_theme"] = theme_name
            self.save_theme_config()
            
            return True, f"Profile theme applied: {success_count}/{total_operations} operations successful"
        
        except Exception as e:
            logger.error(f"Theme application error: {e}")
            return False, f"Error applying theme: {str(e)}"
    

    
    @commands.command(name='profile')
    async def change_profile_theme(self, ctx, theme_name: str = None):
        """Change bot's complete profile theme (avatar, banner, status)
        
        Usage: !profile quantum
        Usage: !profile list (to see available themes)
        """
        # Check permissions
        if ctx.author.id not in self.theme_config.get("allowed_users", []):
            embed = self.bot.create_futuristic_embed(
                "⟨ ❌ ACCESS DENIED ⟩",
                "```yaml\n◇ Only authorized users can change bot profile\n◇ Contact w4xyyy for access\n```",
                'error'
            )
            await ctx.send(embed=embed)
            return
        
        if not self.theme_config.get("enabled", True):
            embed = self.bot.create_futuristic_embed(
                "⟨ ❌ PROFILE SYSTEM DISABLED ⟩",
                "```yaml\n◇ Profile themes are currently disabled\n◇ Contact administrators for assistance\n```",
                'error'
            )
            await ctx.send(embed=embed)
            return
        
        if theme_name and theme_name.lower() == "status":
            current_theme = self.theme_config.get("current_theme", "quantum")
            theme_data = self.profile_themes.get(current_theme, {})
            
            embed = self.bot.create_futuristic_embed(
                "⟨ 📊 CURRENT PROFILE THEME ⟩",
                f"⟨ Active theme: {theme_data.get('name', 'Unknown')} ⟩",
                'neural'
            )
            
            embed.add_field(
                name="⟨ 🎯 ACTIVE THEME ⟩",
                value=f"```yaml\n"
                      f"◇ Theme: {current_theme}\n"
                      f"◇ Name: {theme_data.get('name', 'N/A')}\n"
                      f"◇ Status: {theme_data.get('status', 'N/A')}\n"
                      f"◇ Style: {theme_data.get('description', 'N/A')}\n```",
                inline=False
            )
            
            await ctx.send(embed=embed)
            return
        
        if not theme_name or theme_name.lower() == "list":
            embed = self.bot.create_futuristic_embed(
                "⟨ 🎨 AVAILABLE PROFILE THEMES ⟩",
                "⟨ Complete Discord profile customization like Nitro ⟩",
                'neural'
            )
            
            current_theme = self.theme_config.get("current_theme", "quantum")
            
            for theme_key, theme_data in self.profile_themes.items():
                status_indicator = "🔸 ACTIVE" if theme_key == current_theme else "⚪ Available"
                
                embed.add_field(
                    name=f"⟨ {theme_data['name']} ⟩",
                    value=f"```yaml\n"
                          f"◇ Command: !profile {theme_key}\n"
                          f"◇ Status: {status_indicator}\n"
                          f"◇ Features: Avatar + Banner + Status\n"
                          f"◇ Style: {theme_data['description']}\n```",
                    inline=True
                )
            
            embed.add_field(
                name="⟨ 🔧 COMMANDS ⟩",
                value="```yaml\n"
                      "◇ !profile [name] - Apply theme\n"
                      "◇ !profile list - Show themes\n"
                      "◇ !profile status - Current theme\n```",
                inline=False
            )
            
            await ctx.send(embed=embed)
            return
        
        # Check if theme exists
        if theme_name.lower() not in self.profile_themes:
            available = ", ".join(self.profile_themes.keys())
            embed = self.bot.create_futuristic_embed(
                "⟨ ❌ INVALID THEME ⟩",
                f"```yaml\n"
                f"◇ Theme '{theme_name}' not found\n"
                f"◇ Use: !profile list\n```",
                'error'
            )
            await ctx.send(embed=embed)
            return
        
        # Show processing message
        theme_data = self.profile_themes[theme_name.lower()]
        processing_embed = self.bot.create_futuristic_embed(
            "⟨ 🔄 PROFILE TRANSFORMATION IN PROGRESS ⟩",
            f"```yaml\n"
            f"◇ Applying: {theme_data['name']}\n"
            f"◇ Updating: Avatar, Banner, Status\n"
            f"◇ Please wait...\n```",
            'warning'
        )
        processing_msg = await ctx.send(embed=processing_embed)
        
        # Apply theme
        success, message = await self.apply_profile_theme(theme_name.lower())
        
        if success:
            embed = self.bot.create_futuristic_embed(
                "⟨ ✅ PROFILE TRANSFORMATION COMPLETE ⟩",
                f"```yaml\n"
                f"◇ Theme: {theme_data['name']}\n"
                f"◇ Result: {message}\n"
                f"◇ Bot profile updated successfully\n```",
                'success'
            )
        else:
            embed = self.bot.create_futuristic_embed(
                "⟨ ⚠️ TRANSFORMATION PARTIAL ⟩",
                f"```yaml\n"
                f"◇ Theme: {theme_data['name']}\n"
                f"◇ Result: {message}\n```",
                'warning'
            )
        
        await processing_msg.edit(embed=embed)

    @commands.command(name='random_profile')
    async def random_profile(self, ctx):
        """Apply a random profile theme"""
        # Check permissions
        if ctx.author.id not in self.theme_config.get("allowed_users", []):
            embed = self.bot.create_futuristic_embed(
                "⟨ ❌ ACCESS DENIED ⟩",
                "```yaml\n◇ Only authorized users can change bot profile\n```",
                'error'
            )
            await ctx.send(embed=embed)
            return
        
        import random
        theme_name = random.choice(list(self.profile_themes.keys()))
        
        processing_embed = self.bot.create_futuristic_embed(
            "⟨ 🎲 RANDOM PROFILE GENERATOR ⟩",
            f"```yaml\n"
            f"◇ Selected: {self.profile_themes[theme_name]['name']}\n"
            f"◇ Applying random transformation...\n```",
            'quantum'
        )
        processing_msg = await ctx.send(embed=processing_embed)
        
        success, message = await self.apply_profile_theme(theme_name)
        
        theme_data = self.profile_themes[theme_name]
        if success:
            embed = self.bot.create_futuristic_embed(
                "⟨ ✅ RANDOM TRANSFORMATION COMPLETE ⟩",
                f"```yaml\n"
                f"◇ Applied: {theme_data['name']}\n"
                f"◇ Result: {message}\n"
                f"◇ Surprise theme activated!\n```",
                'success'
            )
        else:
            embed = self.bot.create_futuristic_embed(
                "⟨ ⚠️ TRANSFORMATION PARTIAL ⟩",
                f"```yaml\n"
                f"◇ Theme: {theme_data['name']}\n"
                f"◇ Result: {message}\n```",
                'warning'
            )
        
        await processing_msg.edit(embed=embed)

async def setup(bot):
    await bot.add_cog(ProfileThemes(bot))