import discord
from discord.ext import commands
import logging
import random
from datetime import datetime
import json
import os

logger = logging.getLogger(__name__)

class HolographicGreeting(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.welcome_config = self.load_welcome_config()
        
        # Futuristic welcome themes
        self.neural_greetings = [
            "⟨ New entity detected in quantum matrix ⟩",
            "⟨ Neural signature authenticated ⟩", 
            "⟨ Consciousness upload complete ⟩",
            "⟨ Welcome to the digital realm ⟩",
            "⟨ Quantum entanglement established ⟩"
        ]
        
        self.departure_phrases = [
            "⟨ Neural link severed ⟩",
            "⟨ Entity departed from matrix ⟩",
            "⟨ Quantum signature fading ⟩",
            "⟨ Consciousness disconnected ⟩"
        ]
    
    def load_welcome_config(self):
        """Load welcome configuration"""
        default_config = {
            "enabled": True,
            "channel_id": None,
            "message": "⟨ Neural link established ⟩\n\n**Entity:** {user}\n**Matrix:** {server}\n**ID Classification:** Member #{member_count}\n\n⟨ Quantum synchronization complete ⟩",
            "embed": True,
            "dm_welcome": False,
            "auto_role": None,
            "leave_enabled": True,
            "leave_message": "😢 {user} has left **{server}**. We'll miss you!"
        }
        
        try:
            if os.path.exists('welcome_config.json'):
                with open('welcome_config.json', 'r') as f:
                    config = json.load(f)
                    return {**default_config, **config}
        except Exception as e:
            logger.error(f"Error loading welcome config: {e}")
        
        return default_config
    
    def save_welcome_config(self):
        """Save welcome configuration"""
        try:
            with open('welcome_config.json', 'w') as f:
                json.dump(self.welcome_config, f, indent=4)
        except Exception as e:
            logger.error(f"Error saving welcome config: {e}")
    
    def format_message(self, message: str, member: discord.Member) -> str:
        """Format welcome message with placeholders"""
        return message.format(
            user=member.mention,
            username=member.name,
            server=member.guild.name,
            member_count=member.guild.member_count
        )
    
    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Handle member join events"""
        try:
            if not self.welcome_config.get("enabled", True):
                return
            
            guild = member.guild
            
            # Auto-role assignment
            if self.welcome_config.get("auto_role"):
                try:
                    role = discord.utils.get(guild.roles, name=self.welcome_config["auto_role"])
                    if role:
                        await member.add_roles(role, reason="Auto-role on join")
                except Exception as e:
                    logger.error(f"Error assigning auto-role: {e}")
            
            # Welcome message
            channel_id = self.welcome_config.get("channel_id")
            if channel_id:
                channel = self.bot.get_channel(channel_id)
                if channel:
                    message = self.format_message(self.welcome_config["message"], member)
                    
                    if self.welcome_config.get("embed", True):
                        embed = discord.Embed(
                            title="👋 Welcome!",
                            description=message,
                            color=discord.Color.green(),
                            timestamp=datetime.utcnow()
                        )
                        embed.set_thumbnail(url=member.display_avatar.url)
                        embed.set_footer(text=f"Account created: {member.created_at.strftime('%Y-%m-%d')}")
                        await channel.send(embed=embed)
                    else:
                        await channel.send(message)
            
            # DM welcome
            if self.welcome_config.get("dm_welcome", False):
                try:
                    dm_message = f"Welcome to **{guild.name}**! Thanks for joining our community."
                    await member.send(dm_message)
                except discord.Forbidden:
                    pass  # User has DMs disabled
            
        except Exception as e:
            logger.error(f"Error in member join handler: {e}")
    
    @commands.Cog.listener()
    async def on_member_remove(self, member):
        """Handle member leave events"""
        try:
            if not self.welcome_config.get("leave_enabled", True):
                return
            
            channel_id = self.welcome_config.get("channel_id")
            if channel_id:
                channel = self.bot.get_channel(channel_id)
                if channel:
                    message = self.format_message(self.welcome_config["leave_message"], member)
                    
                    embed = discord.Embed(
                        title="👋 Goodbye",
                        description=message,
                        color=discord.Color.orange(),
                        timestamp=datetime.utcnow()
                    )
                    embed.set_thumbnail(url=member.display_avatar.url)
                    await channel.send(embed=embed)
        
        except Exception as e:
            logger.error(f"Error in member leave handler: {e}")
    
    @commands.command(name='welcome_setup')
    @commands.has_permissions(manage_guild=True)
    async def setup_welcome(self, ctx, channel: discord.TextChannel = None):
        """Set up welcome channel"""
        if channel is None:
            channel = ctx.channel
        
        self.welcome_config["channel_id"] = channel.id
        self.welcome_config["enabled"] = True
        self.save_welcome_config()
        
        embed = discord.Embed(
            title="✅ Welcome System Setup",
            description=f"Welcome messages will be sent to {channel.mention}",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)
    
    @commands.command(name='welcome_message')
    @commands.has_permissions(manage_guild=True)
    async def set_welcome_message(self, ctx, *, message: str):
        """Set custom welcome message
        
        Available placeholders:
        {user} - User mention
        {username} - Username
        {server} - Server name
        {member_count} - Member count
        """
        self.welcome_config["message"] = message
        self.save_welcome_config()
        
        embed = discord.Embed(
            title="✅ Welcome Message Updated",
            description=f"New welcome message:\n{message}",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)
    
    @commands.command(name='welcome_test')
    @commands.has_permissions(manage_guild=True)
    async def test_welcome(self, ctx, member: discord.Member = None):
        """Test welcome message"""
        if member is None:
            member = ctx.author
        
        message = self.format_message(self.welcome_config["message"], member)
        
        embed = discord.Embed(
            title="👋 Welcome Test",
            description=message,
            color=discord.Color.blue(),
            timestamp=datetime.utcnow()
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text=f"Account created: {member.created_at.strftime('%Y-%m-%d')}")
        await ctx.send(embed=embed)
    
    @commands.command(name='welcome_autorole')
    @commands.has_permissions(manage_roles=True)
    async def set_auto_role(self, ctx, *, role_name: str = None):
        """Set auto-role for new members"""
        if role_name is None:
            self.welcome_config["auto_role"] = None
            self.save_welcome_config()
            await ctx.send("✅ Auto-role disabled.")
            return
        
        role = discord.utils.get(ctx.guild.roles, name=role_name)
        if not role:
            await ctx.send(f"❌ Role '{role_name}' not found.")
            return
        
        self.welcome_config["auto_role"] = role_name
        self.save_welcome_config()
        
        embed = discord.Embed(
            title="✅ Auto-Role Set",
            description=f"New members will automatically receive the {role.mention} role.",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)
    
    @commands.command(name='welcome_config')
    @commands.has_permissions(manage_guild=True)
    async def show_welcome_config(self, ctx):
        """Show current welcome configuration"""
        config = self.welcome_config
        channel = self.bot.get_channel(config.get("channel_id"))
        
        embed = discord.Embed(
            title="⚙️ Welcome Configuration",
            color=discord.Color.blue()
        )
        
        embed.add_field(name="Enabled", value="✅" if config.get("enabled") else "❌", inline=True)
        embed.add_field(name="Channel", value=channel.mention if channel else "Not set", inline=True)
        embed.add_field(name="Auto-Role", value=config.get("auto_role", "None"), inline=True)
        embed.add_field(name="DM Welcome", value="✅" if config.get("dm_welcome") else "❌", inline=True)
        embed.add_field(name="Leave Messages", value="✅" if config.get("leave_enabled") else "❌", inline=True)
        embed.add_field(name="Use Embed", value="✅" if config.get("embed") else "❌", inline=True)
        
        embed.add_field(name="Welcome Message", value=config.get("message", "Default"), inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='welcome_toggle')
    @commands.has_permissions(manage_guild=True)
    async def toggle_welcome(self, ctx, feature: str = None):
        """Toggle welcome features (enabled/dm_welcome/leave_enabled/embed)"""
        if feature is None:
            await ctx.send("Usage: `!welcome_toggle <enabled/dm_welcome/leave_enabled/embed>`")
            return
        
        if feature not in ["enabled", "dm_welcome", "leave_enabled", "embed"]:
            await ctx.send("❌ Invalid feature. Options: enabled, dm_welcome, leave_enabled, embed")
            return
        
        current = self.welcome_config.get(feature, False)
        self.welcome_config[feature] = not current
        self.save_welcome_config()
        
        status = "enabled" if self.welcome_config[feature] else "disabled"
        embed = discord.Embed(
            title="✅ Setting Updated",
            description=f"{feature.replace('_', ' ').title()} is now {status}.",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(HolographicGreeting(bot))