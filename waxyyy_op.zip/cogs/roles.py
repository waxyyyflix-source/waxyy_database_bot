import discord
from discord.ext import commands
import logging
from utils.permissions import has_role_permissions
from utils.logging_utils import log_action

logger = logging.getLogger(__name__)

class RoleManagement(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name='createrole')
    @commands.has_permissions(manage_roles=True)
    async def create_role(self, ctx, name: str, color: str = None, *, permissions=None):
        """Create a new role"""
        try:
            # Parse color
            role_color = discord.Color.default()
            if color:
                try:
                    if color.startswith('#'):
                        role_color = discord.Color(int(color[1:], 16))
                    else:
                        role_color = getattr(discord.Color, color.lower(), discord.Color.default)()
                except (ValueError, AttributeError):
                    await ctx.send(f"❌ Invalid color: {color}. Using default color.")
            
            # Create role
            role = await ctx.guild.create_role(
                name=name,
                color=role_color,
                reason=f"Role created by {ctx.author}"
            )
            
            # Log the action
            await log_action(ctx, "CREATE_ROLE", role, f"Created role: {name}")
            
            embed = discord.Embed(
                title="✅ Role Created",
                description=f"**Role:** {role.mention}\n**Color:** {role.color}",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
            
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to create roles.")
        except Exception as e:
            logger.error(f"Error creating role: {e}")
            await ctx.send("❌ An error occurred while creating the role.")
    
    @commands.command(name='deleterole')
    @commands.has_permissions(manage_roles=True)
    async def delete_role(self, ctx, *, role_name: str):
        """Delete a role"""
        try:
            role = discord.utils.get(ctx.guild.roles, name=role_name)
            if not role:
                await ctx.send(f"❌ Role '{role_name}' not found.")
                return
            
            if not has_role_permissions(ctx.author, role):
                await ctx.send("❌ You cannot delete this role (higher or equal role hierarchy).")
                return
            
            role_mention = role.mention
            await role.delete(reason=f"Role deleted by {ctx.author}")
            
            # Log the action
            await log_action(ctx, "DELETE_ROLE", None, f"Deleted role: {role_name}")
            
            embed = discord.Embed(
                title="✅ Role Deleted",
                description=f"**Role:** {role_name}",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
            
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to delete this role.")
        except Exception as e:
            logger.error(f"Error deleting role: {e}")
            await ctx.send("❌ An error occurred while deleting the role.")
    
    @commands.command(name='addrole')
    @commands.has_permissions(manage_roles=True)
    async def add_role(self, ctx, member: discord.Member, *, role_name: str):
        """Add a role to a member"""
        try:
            role = discord.utils.get(ctx.guild.roles, name=role_name)
            if not role:
                await ctx.send(f"❌ Role '{role_name}' not found.")
                return
            
            if not has_role_permissions(ctx.author, role):
                await ctx.send("❌ You cannot assign this role (higher or equal role hierarchy).")
                return
            
            if role in member.roles:
                await ctx.send(f"❌ {member.mention} already has the role {role.mention}.")
                return
            
            await member.add_roles(role, reason=f"Role added by {ctx.author}")
            
            # Log the action
            await log_action(ctx, "ADD_ROLE", member, f"Added role: {role.name}")
            
            embed = discord.Embed(
                title="✅ Role Added",
                description=f"**Member:** {member.mention}\n**Role:** {role.mention}",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
            
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to add roles to this member.")
        except Exception as e:
            logger.error(f"Error adding role: {e}")
            await ctx.send("❌ An error occurred while adding the role.")
    
    @commands.command(name='removerole')
    @commands.has_permissions(manage_roles=True)
    async def remove_role(self, ctx, member: discord.Member, *, role_name: str):
        """Remove a role from a member"""
        try:
            role = discord.utils.get(ctx.guild.roles, name=role_name)
            if not role:
                await ctx.send(f"❌ Role '{role_name}' not found.")
                return
            
            if not has_role_permissions(ctx.author, role):
                await ctx.send("❌ You cannot remove this role (higher or equal role hierarchy).")
                return
            
            if role not in member.roles:
                await ctx.send(f"❌ {member.mention} doesn't have the role {role.mention}.")
                return
            
            await member.remove_roles(role, reason=f"Role removed by {ctx.author}")
            
            # Log the action
            await log_action(ctx, "REMOVE_ROLE", member, f"Removed role: {role.name}")
            
            embed = discord.Embed(
                title="✅ Role Removed",
                description=f"**Member:** {member.mention}\n**Role:** {role.mention}",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
            
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to remove roles from this member.")
        except Exception as e:
            logger.error(f"Error removing role: {e}")
            await ctx.send("❌ An error occurred while removing the role.")
    
    @commands.command(name='listroles')
    async def list_roles(self, ctx):
        """List all roles in the server"""
        try:
            roles = sorted(ctx.guild.roles, key=lambda r: r.position, reverse=True)
            
            # Filter out @everyone role and bot roles for cleaner display
            display_roles = [role for role in roles if role.name != "@everyone"]
            
            if not display_roles:
                await ctx.send("❌ No roles found in this server.")
                return
            
            # Create embed with role list
            embed = discord.Embed(
                title=f"📋 Roles in {ctx.guild.name}",
                color=discord.Color.blue()
            )
            
            # Split roles into chunks to avoid hitting embed limits
            role_chunks = [display_roles[i:i+20] for i in range(0, len(display_roles), 20)]
            
            for i, chunk in enumerate(role_chunks):
                role_list = ""
                for role in chunk:
                    member_count = len(role.members)
                    role_list += f"{role.mention} - {member_count} members\n"
                
                field_name = f"Roles ({i*20 + 1}-{i*20 + len(chunk)})" if len(role_chunks) > 1 else "Roles"
                embed.add_field(name=field_name, value=role_list, inline=False)
            
            embed.set_footer(text=f"Total roles: {len(display_roles)}")
            await ctx.send(embed=embed)
            
        except Exception as e:
            logger.error(f"Error listing roles: {e}")
            await ctx.send("❌ An error occurred while listing roles.")
    
    @commands.command(name='roleinfo')
    async def role_info(self, ctx, *, role_name: str):
        """Get detailed information about a role"""
        try:
            role = discord.utils.get(ctx.guild.roles, name=role_name)
            if not role:
                await ctx.send(f"❌ Role '{role_name}' not found.")
                return
            
            embed = discord.Embed(
                title=f"📊 Role Information: {role.name}",
                color=role.color
            )
            
            embed.add_field(name="Name", value=role.name, inline=True)
            embed.add_field(name="ID", value=role.id, inline=True)
            embed.add_field(name="Position", value=role.position, inline=True)
            embed.add_field(name="Color", value=str(role.color), inline=True)
            embed.add_field(name="Hoisted", value="Yes" if role.hoist else "No", inline=True)
            embed.add_field(name="Mentionable", value="Yes" if role.mentionable else "No", inline=True)
            embed.add_field(name="Members", value=len(role.members), inline=True)
            embed.add_field(name="Created", value=role.created_at.strftime("%Y-%m-%d %H:%M:%S"), inline=True)
            
            # Show some permissions
            perms = []
            if role.permissions.administrator:
                perms.append("Administrator")
            if role.permissions.manage_guild:
                perms.append("Manage Server")
            if role.permissions.manage_roles:
                perms.append("Manage Roles")
            if role.permissions.manage_channels:
                perms.append("Manage Channels")
            if role.permissions.kick_members:
                perms.append("Kick Members")
            if role.permissions.ban_members:
                perms.append("Ban Members")
            
            if perms:
                embed.add_field(name="Key Permissions", value=", ".join(perms), inline=False)
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            logger.error(f"Error getting role info: {e}")
            await ctx.send("❌ An error occurred while getting role information.")

async def setup(bot):
    await bot.add_cog(RoleManagement(bot))
