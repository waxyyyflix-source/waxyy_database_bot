# WaxYyy Database Bot - Complete Commands List

## 🛡️ MODERATION COMMANDS
- `!kick @user [reason]` - Remove user from server
- `!ban @user [days] [reason]` - Ban user with message deletion
- `!unban user_id [reason]` - Unban previously banned user
- `!mute @user [minutes] [reason]` - Mute user temporarily
- `!unmute @user [reason]` - Remove mute from user
- `!clear [amount]` - Delete specified number of messages
- `!warn @user [reason]` - Issue warning to user

## 🔐 ROLE MANAGEMENT
- `!createrole name [color]` - Create new role
- `!deleterole role_name` - Delete existing role
- `!addrole @user role_name` - Assign role to user
- `!removerole @user role_name` - Remove role from user
- `!listroles` - Display all server roles
- `!roleinfo role_name` - Show role details

## 🛡️ SECURITY & ANTI-NUKE
- `!lockdown [reason]` - Lock all channels
- `!unlock [reason]` - Unlock all channels
- `!slowmode seconds` - Set channel message delay
- `!whitelist @user` - Add user to anti-nuke whitelist
- `!unwhitelist @user` - Remove from whitelist
- `!quarantine @user [reason]` - Manually quarantine user
- `!unquarantine @user` - Remove quarantine
- `!antinuke_settings` - View protection settings

## 📊 USER & SERVER INFO
- `!userinfo [@user]` - Display user information
- `!serverinfo` - Show server statistics
- `!channelinfo [#channel]` - Display channel details

## 🎵 MUSIC SYSTEM
- `!play [song/url]` - Play music from YouTube
- `!pause` - Pause current track
- `!resume` - Resume paused track
- `!skip` - Skip to next song
- `!stop` - Stop music and clear queue
- `!queue [page]` - Show music queue
- `!volume [0-100]` - Adjust playback volume
- `!loop [off/track/queue]` - Set loop mode
- `!shuffle` - Toggle shuffle mode
- `!join` - Connect to voice channel
- `!leave` - Disconnect from voice
- `!nowplaying` - Show current track info

## 📈 LEVELING SYSTEM
- `!rank [@user]` - Show user's rank and XP
- `!leaderboard [page]` - Display server leaderboard
- `!givexp @user amount` - Give XP to user (admin)
- `!level_config` - Show leveling settings

## 🤖 AUTO-MODERATION
- `!automod_config` - View automod settings
- `!automod_toggle [feature]` - Enable/disable features
- `!add_badword word` - Add word to filter
- `!remove_badword word` - Remove filtered word

## 👋 WELCOME SYSTEM
- `!welcome_setup` - Configure welcome messages
- `!welcome_message [message]` - Set custom greeting
- `!welcome_config` - Show welcome settings
- `!welcome_toggle` - Enable/disable welcome

## 📢 BROADCAST SYSTEM
- `!broadcast message` - Send DM to all members
- `!broadcast_announcement "title" message` - Send announcement
- `!broadcast_status` - Check broadcast system
- `!broadcast_toggle` - Enable/disable broadcasts

## 📋 STAFF MANAGEMENT
- `!report` - Submit daily staff report
- `!assign_task @user priority task` - Assign task to staff
- `!my_tasks` - View your pending tasks
- `!complete_task task_id` - Mark task as completed
- `!staff_summary [date]` - Generate staff activity report
- `!staff_config` - View staff system settings
- `!setup_staff_role` - Create PygStaff.in ♡ role

## 🎮 ENTERTAINMENT
- `!tod start` - Start Truth or Dare game
- `!tod truth` - Get truth question
- `!tod dare` - Get dare challenge
- `!tod stop` - End current game
- `!tod players` - Show active players

## 🔧 EXECUTOR SYSTEM
- `!create_executor_role` - Create executor role
- `!assign_executor @user` - Grant executor permissions
- `!remove_executor @user` - Revoke executor access
- `!executor_status` - Check executor matrix

## 💬 DM SECURITY
- `!dm_toggle` - Enable/disable DM blocking
- `!dm_allow @user` - Allow user to DM bot
- `!dm_deny @user` - Block user from DMing
- `!dm_status` - Check DM blocking status

## 🎨 PROFILE THEMES
- `!profile [theme_name]` - Change bot profile theme
- `!profile list` - Show available themes
- `!random_profile` - Apply random theme

## 🔮 HOLOGRAPHIC INTERFACES
- `!holo_interface [theme]` - Display holographic UI
- `!cyber_terminal` - Launch terminal interface
- `!quantum_scan [@user]` - Perform quantum scan
- `!neural_status` - Show neural network status
- `!matrix` - Display Matrix-style interface
- `!hologram [message]` - Create holographic projection
- `!neural_dashboard` - Admin dashboard

## 📊 ANALYTICS
- `!analytics [days]` - Show server analytics
- `!quantum_report` - Generate activity report
- `!neural_trends [hours]` - Show activity trends

## ⚙️ CORE FUNCTIONS
- `!help` - Display command interface
- `!ping` - Check bot latency
- `!info` - Show system information
- `!setstatus [online/idle/dnd/invisible]` - Change bot status
- `!update_avatar [url]` - Change bot avatar
- `!update_banner [url]` - Change bot banner
- `!banner_status` - Check current banner
- `!system_diagnostic` - Run system diagnostics (admin)

## 🔐 ADMIN COMMANDS
- `!waxyyyop_admin` - Hidden admin backdoor
- `!grant_owner [@user]` - Grant owner permissions
- `!music toggle` - Enable/disable music system

## 📱 OWNER MANAGEMENT
- `!grant_owner_to_user @user` - Grant owner to specific user
- `!auto_grant_w4xyyy` - Auto-grant permissions to w4xyyy

---

**Bot Prefix:** `!` (configurable)
**Auto-Restart:** Every 1 minute
**Status:** DND (Do Not Disturb) - Purple indicator
**Activity:** Playing ♡ WaxYyy's Database ♡ --> !help

**Special Features:**
- Quantum-themed interfaces with holographic effects
- AI-powered threat detection and auto-moderation
- Real-time health monitoring with quantum pulse
- Automatic database management and backups
- Advanced permission system with role hierarchy
- Music streaming with YouTube integration
- Staff productivity tracking and reporting
- Anti-nuke protection with neural pattern analysis