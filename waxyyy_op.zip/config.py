import json
import os
import logging

logger = logging.getLogger(__name__)

class BotConfig:
    def __init__(self, config_file='bot_config.json'):
        self.config_file = config_file
        self.prefix = "!"
        self.log_channel_id = None
        self.muted_role_name = "Muted"
        self.max_warnings = 3
        self.auto_mod = True
        self.load_config()
    
    def load_config(self):
        """Load configuration from JSON file"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config_data = json.load(f)
                    self.prefix = config_data.get('prefix', self.prefix)
                    self.log_channel_id = config_data.get('log_channel_id', self.log_channel_id)
                    self.muted_role_name = config_data.get('muted_role_name', self.muted_role_name)
                    self.max_warnings = config_data.get('max_warnings', self.max_warnings)
                    self.auto_mod = config_data.get('auto_mod', self.auto_mod)
                logger.info("Configuration loaded successfully")
            else:
                self.save_config()  # Create default config file
                logger.info("Created default configuration file")
        except Exception as e:
            logger.error(f"Failed to load configuration: {e}")
    
    def save_config(self):
        """Save current configuration to JSON file"""
        try:
            config_data = {
                'prefix': self.prefix,
                'log_channel_id': self.log_channel_id,
                'muted_role_name': self.muted_role_name,
                'max_warnings': self.max_warnings,
                'auto_mod': self.auto_mod
            }
            with open(self.config_file, 'w') as f:
                json.dump(config_data, f, indent=4)
            logger.info("Configuration saved successfully")
        except Exception as e:
            logger.error(f"Failed to save configuration: {e}")
    
    def update_config(self, **kwargs):
        """Update configuration values"""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
        self.save_config()
