import discord
import logging
import os
from datetime import datetime

def setup_logging():
    """Set up logging configuration"""
    # Create logs directory if it doesn't exist
    if not os.path.exists('logs'):
        os.makedirs('logs')
    
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(f'logs/bot_{datetime.now().strftime("%Y%m%d")}.log'),
            logging.StreamHandler()
        ]
    )

async def log_action(ctx, action_type: str, target, reason: str):
    """Log moderation actions to a channel and file"""
    logger = logging.getLogger(__name__)
    
    try:
        # Log to file
        log_message = f"[{action_type}] {ctx.author} ({ctx.author.id}) - Target: {target} - Reason: {reason}"
        logger.info(log_message)
        
        # Try to log to Discord channel if configured
        if hasattr(ctx.bot, 'config') and ctx.bot.config.log_channel_id:
            log_channel = ctx.bot.get_channel(ctx.bot.config.log_channel_id)
            if log_channel:
                embed = discord.Embed(
                    title=f"🔍 Moderation Action: {action_type}",
                    color=get_action_color(action_type),
                    timestamp=datetime.utcnow()
                )
                
                embed.add_field(name="Moderator", value=f"{ctx.author.mention} ({ctx.author})", inline=True)
                embed.add_field(name="Channel", value=ctx.channel.mention, inline=True)
                
                if target:
                    if isinstance(target, (discord.Member, discord.User)):
                        embed.add_field(name="Target User", value=f"{target.mention} ({target})", inline=True)
                    elif isinstance(target, discord.Role):
                        embed.add_field(name="Target Role", value=target.mention, inline=True)
                    elif isinstance(target, discord.TextChannel):
                        embed.add_field(name="Target Channel", value=target.mention, inline=True)
                    else:
                        embed.add_field(name="Target", value=str(target), inline=True)
                
                embed.add_field(name="Reason", value=reason, inline=False)
                embed.set_footer(text=f"Action ID: {datetime.utcnow().strftime('%Y%m%d%H%M%S')}")
                
                await log_channel.send(embed=embed)
    
    except Exception as e:
        logger.error(f"Error logging action: {e}")

def get_action_color(action_type: str) -> discord.Color:
    """Get color for different action types"""
    color_map = {
        "KICK": discord.Color.orange(),
        "BAN": discord.Color.red(),
        "UNBAN": discord.Color.green(),
        "MUTE": discord.Color.dark_grey(),
        "UNMUTE": discord.Color.light_grey(),
        "WARN": discord.Color.yellow(),
        "CREATE_ROLE": discord.Color.blue(),
        "DELETE_ROLE": discord.Color.dark_red(),
        "ADD_ROLE": discord.Color.green(),
        "REMOVE_ROLE": discord.Color.orange(),
        "LOCKDOWN": discord.Color.dark_red(),
        "UNLOCK": discord.Color.green(),
        "SLOWMODE": discord.Color.blue()
    }
    return color_map.get(action_type, discord.Color.default())

async def log_security_event(bot, guild, event_type: str, details: str):
    """Log security events"""
    logger = logging.getLogger(__name__)
    
    try:
        log_message = f"[SECURITY] {guild.name} ({guild.id}) - {event_type}: {details}"
        logger.warning(log_message)
        
        # Try to log to Discord channel if configured
        if hasattr(bot, 'config') and bot.config.log_channel_id:
            log_channel = bot.get_channel(bot.config.log_channel_id)
            if log_channel:
                embed = discord.Embed(
                    title="🚨 Security Event",
                    description=f"**Event:** {event_type}\n**Details:** {details}",
                    color=discord.Color.red(),
                    timestamp=datetime.utcnow()
                )
                embed.add_field(name="Server", value=f"{guild.name} ({guild.id})", inline=False)
                await log_channel.send(embed=embed)
    
    except Exception as e:
        logger.error(f"Error logging security event: {e}")
