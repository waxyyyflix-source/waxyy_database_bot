import discord
import logging

logger = logging.getLogger(__name__)

def has_mod_permissions(author: discord.Member, target: discord.Member) -> bool:
    """Check if author has permission to moderate target member"""
    try:
        # Bot owner always has permission
        if author.guild.owner == author:
            return True
        
        # Check role hierarchy
        if author.top_role <= target.top_role:
            return False
        
        return True
    except Exception as e:
        logger.error(f"Error checking mod permissions: {e}")
        return False

def has_role_permissions(author: discord.Member, role: discord.Role) -> bool:
    """Check if author has permission to manage a specific role"""
    try:
        # Bot owner always has permission
        if author.guild.owner == author:
            return True
        
        # Check if author's highest role is higher than the target role
        if author.top_role <= role:
            return False
        
        return True
    except Exception as e:
        logger.error(f"Error checking role permissions: {e}")
        return False

def can_execute_command(author: discord.Member, required_permissions: list) -> bool:
    """Check if author has required permissions to execute a command"""
    try:
        author_perms = author.guild_permissions
        
        for perm in required_permissions:
            if not getattr(author_perms, perm, False):
                return False
        
        return True
    except Exception as e:
        logger.error(f"Error checking command permissions: {e}")
        return False

def is_admin(member: discord.Member) -> bool:
    """Check if member has administrator permissions"""
    try:
        return member.guild_permissions.administrator or member.guild.owner == member
    except Exception as e:
        logger.error(f"Error checking admin permissions: {e}")
        return False

def is_moderator(member: discord.Member) -> bool:
    """Check if member has moderation permissions"""
    try:
        perms = member.guild_permissions
        return (perms.administrator or 
                perms.manage_guild or 
                perms.kick_members or 
                perms.ban_members or 
                perms.manage_messages or
                member.guild.owner == member)
    except Exception as e:
        logger.error(f"Error checking moderator permissions: {e}")
        return False

def has_higher_role(author: discord.Member, target: discord.Member) -> bool:
    """Check if author has a higher role than target"""
    try:
        return author.top_role > target.top_role
    except Exception as e:
        logger.error(f"Error checking role hierarchy: {e}")
        return False
