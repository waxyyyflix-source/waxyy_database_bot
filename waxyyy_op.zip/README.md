# Professional Discord Security Bot

A comprehensive Discord security bot with advanced moderation, anti-nuke protection, leveling system, and welcome features.

## Features

### 🛡️ Security & Moderation
- **Anti-Nuke Protection**: Monitors and prevents server destruction attempts
- **Comprehensive Moderation**: Kick, ban, mute, warn, and message management
- **Role Management**: Create, delete, assign, and manage server roles
- **Channel Security**: Lockdown, slowmode, and permission management

### 🤖 AutoMod System
- **Anti-Spam**: Prevents message flooding
- **Content Filtering**: Bad words, excessive caps, and link filtering
- **Invite Protection**: Discord invite detection and removal
- **Mention Limits**: Prevents excessive user/role mentions

### 👋 Welcome System
- **Custom Welcome Messages**: Personalized greetings with placeholders
- **Auto-Role Assignment**: Automatic role assignment for new members
- **Leave Messages**: Goodbye messages when members leave
- **DM Welcome**: Optional direct message welcome

### 📈 Leveling System
- **XP Tracking**: Persistent experience points from messages
- **Rank Cards**: Individual user rank and progress display
- **Leaderboard**: Server-wide ranking system
- **Level Rewards**: Role rewards for reaching levels

## Commands

### Moderation Commands
- `!kick @user [reason]` - Kick a member
- `!ban @user [days] [reason]` - Ban a member
- `!unban user_id [reason]` - Unban a member
- `!mute @user [minutes] [reason]` - Mute a member
- `!unmute @user [reason]` - Unmute a member
- `!clear [amount]` - Delete messages
- `!warn @user [reason]` - Warn a member

### Role Management
- `!createrole name [color]` - Create a new role
- `!deleterole role_name` - Delete a role
- `!addrole @user role_name` - Add role to user
- `!removerole @user role_name` - Remove role from user
- `!listroles` - List all server roles
- `!roleinfo role_name` - Get role information

### Security Commands
- `!lockdown [reason]` - Lock all channels
- `!unlock [reason]` - Unlock all channels
- `!slowmode seconds` - Set channel slowmode
- `!userinfo [@user]` - Get user information
- `!serverinfo` - Get server information
- `!channelinfo [#channel]` - Get channel information

### Anti-Nuke Commands
- `!whitelist @user` - Add user to anti-nuke whitelist
- `!unwhitelist @user` - Remove from whitelist
- `!quarantine @user [reason]` - Manually quarantine user
- `!unquarantine @user` - Remove from quarantine
- `!antinuke_settings` - View protection settings

### Welcome System
- `!welcome_setup [#channel]` - Set welcome channel
- `!welcome_message <message>` - Set custom welcome message
- `!welcome_test [@user]` - Test welcome message
- `!welcome_autorole [role_name]` - Set auto-role
- `!welcome_config` - View welcome settings
- `!welcome_toggle <feature>` - Toggle welcome features

### Leveling System
- `!rank [@user]` - Check user rank and level
- `!leaderboard [page]` - View server leaderboard
- `!givexp @user amount` - Give XP to user (Admin only)
- `!level_config` - View leveling settings
- `!level_toggle` - Toggle leveling system

### AutoMod Commands
- `!automod_config` - View automod settings
- `!automod_toggle [feature]` - Toggle automod features
- `!add_badword <word>` - Add word to filter
- `!remove_badword <word>` - Remove word from filter

### General Commands
- `!help` - Show all commands
- `!ping` - Check bot latency

## Setup Instructions

### 1. Bot Token
1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Create a new application or select existing one
3. Go to "Bot" section and copy the token
4. Add the token as `DISCORD_BOT_TOKEN` environment variable

### 2. Bot Permissions
The bot requires the following permissions:
- Administrator (recommended) or specific permissions:
  - Manage Server
  - Manage Roles
  - Manage Channels
  - Kick Members
  - Ban Members
  - Manage Messages
  - Read Message History
  - Send Messages
  - Embed Links
  - Attach Files
  - Use External Emojis

### 3. Bot Invite
Generate an invite link with required permissions and add the bot to your server.

## Configuration

### Bot Settings
Edit `bot_config.json` to customize:
```json
{
    "prefix": "!",
    "log_channel_id": null,
    "muted_role_name": "Muted",
    "max_warnings": 3,
    "auto_mod": true
}
```

### Welcome Messages
Available placeholders:
- `{user}` - User mention
- `{username}` - Username
- `{server}` - Server name
- `{member_count}` - Total member count

### Anti-Nuke Protection
Configurable limits for:
- Channel deletions: 3 per 60 seconds
- Channel creations: 5 per 60 seconds
- Role deletions: 3 per 60 seconds
- Role creations: 5 per 60 seconds
- Member bans: 5 per 60 seconds

## Database

The bot uses SQLite for persistent data storage:
- `leveling.db` - User XP and level data
- Configuration files for features

## Logging

All actions are logged to:
- Console output
- Daily log files in `logs/` directory
- Optional Discord log channel

## Support

For issues or feature requests, ensure the bot has proper permissions and check the console logs for error messages.